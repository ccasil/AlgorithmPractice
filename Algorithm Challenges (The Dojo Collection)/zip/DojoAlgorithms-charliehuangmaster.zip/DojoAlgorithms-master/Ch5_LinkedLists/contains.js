/* Given a ListNode pointer and a val, return if val is found in any node in the list */

function contains(node, value) {
    var currentNode = node;
    while (currentNode.next) {
        if (currentNode.val === value) {
            return true;
        }
        currentNode = currentNode.next;
    }
    return false;
}

function ListNode(value) {
    this.val = value;
    this.next = null;
}