/* Create a function to return a copy of a list. Do not return the same list, but instead make a copy of each node in the list and connect them in the same order as the original. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SList() {
    this.head = null;
}

SList.prototype.copy = function() {
    var copiedList = new SList();
    copiedList.head = new SLNode(this.head.val);
    var runner = this.head;
    var runner2 = copiedList.head;
    while (runner.next) {
        runner2.next = new SLNode(runner.next.val);
        runner = runner.next;
        runner2 = runner2.next;
    }
    return copiedList;
}