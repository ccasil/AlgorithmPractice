/* Create a function that locates the minimum value in a SList and moves that node to the front of the list. Return the new list and all nodes (except for hte new head node) in their original order */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SList() {
    this.head = null;
}

SList.prototype.moveMinToFront = function() {
    var min = this.head.val;
    var runner = this.head;
    while (runner.next) {
        if (runner.val < min) {
            min = runner.val;
        }
        runner = runner.next;
    }

    var runner = this.head;
    while (runner.next) {
        if (runner.next.val === min) {
            var temp = runner.next.next;
            runner.next.next = this.head;
            this.head = runner.next;
            runner.next = temp;
        }
        runner = runner.next;
    }
    return this;
}