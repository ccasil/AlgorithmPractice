/* Create a function that accepts a pointer to a list's head node and returns the list's largest value */

function max(headNode) {
    var maxVal = headNode.val;
    var runner = headNode;
    while (runner.next) {
        runner = runner.next;
        if (runner.val > maxVal) {
            maxVal = runner.val;
        }
    }
    return maxVal;
}

function ListNode(value) {
    this.val = value;
    this.next = null;
}