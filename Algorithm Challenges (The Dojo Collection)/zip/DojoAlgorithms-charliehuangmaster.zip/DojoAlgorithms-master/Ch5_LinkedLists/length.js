/* Create a function that accepts a pointer to the first list node and returns the number of nodes in that SList */

function length(head) {
    var length = 1;
    var runner = head;
    while (runner.next) {
        runner = runner.next;
        length++;
    }
    return length;
}

function ListNode(value) {
    this.val = value;
    this.next = null;
}