/* Create appendVal(val, after) that inserts a new ListNode with val immediately after the node containing after (or at end, if after is not found). Return the new list */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SLList() {
    this.head = null;
}

SLList.prototype.appendVal = function(val, after) {
    var newNode = new ListNode(val);
    var runner = this.head;
    while (runner.next) {
        if (runner.val === after) {
            newNode.next = runner.next;
            runner.next = newNode;
            return this;
        }
        runner = runner.next;
    }
    runner.next = newNode;
    return this;
}