/* Create a function that locates the maximum value in a linked list and moves that node to the back of the list. Return the new list with all nodes still present and in their original order except for the node that was moved to the end of the list */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SList() {
    this.head = null;
}

SList.prototype.moveMaxToBack = function() {
    var max = this.head.val;
    var runner = this.head;
    while (runner.next) {
        if (runner.val > max) {
            max = runner.val;
        }
        runner = runner.next;
    }

    runner = this.head;
    if (runner.val === max) { // if max is at front of list
        var temp = runner;
        this.head = runner.next;
        while (runner.next) {
            runner = runner.next;
        }
        runner.next = temp;
    } else {
        while (runner.next) {
            if (runner.next.val === max) {
                var temp = runner.next;
                runner.next = runner.next.next;
                temp.next = null;
            }
            runner = runner.next;
        }
        runner.next = temp;
    }
    return this;
}