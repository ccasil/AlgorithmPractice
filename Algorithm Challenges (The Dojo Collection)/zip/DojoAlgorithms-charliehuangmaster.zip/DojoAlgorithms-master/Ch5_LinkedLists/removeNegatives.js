/* Remove any nodes containing negative values and return the new list */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SList() {
    this.head = null;
}

SList.prototype.removeNegatives = function() {
    var runner = this.head;

    // if list starts with negative nodes, find the first positive one
    while (runner) {
        if (runner.val >= 0) {
            this.head = runner;
            break;
        }
        runner = runner.next;
    }

    runner = this.head;
    while (runner) {
        // go through rest of list and find the next positive node
        var runner2 = runner.next;
        while (runner2) {
            if (runner2.val >= 0) {
                runner.next = runner2;
                break;
            }
            runner2 = runner2.next;
        }
        runner = runner.next;
    }
    return this;
}