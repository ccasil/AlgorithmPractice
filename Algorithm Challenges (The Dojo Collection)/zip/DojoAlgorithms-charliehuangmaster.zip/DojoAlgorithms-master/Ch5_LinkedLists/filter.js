/* Given a lowVal nad a highVal, remove from the list any nodes that have values less than lowVal or higher than highVal. Return the new list. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SList() {
    this.head = null;
}

SList.prototype.filter = function(lowVal, highVal) {
    var runner = this.head;
    while (runner) {
        if (runner.val < lowVal || runner.val > highVal) {
            this.head = runner.next;
        }
        runner = runner.next;
    }
    runner = this.head;
    while (runner.next) {
        if (runner.next.val < lowVal || runner.next.val > highVal) {
            runner.next = runner.next.next;
        }
        runner = runner.next;
    }
    return this;
}