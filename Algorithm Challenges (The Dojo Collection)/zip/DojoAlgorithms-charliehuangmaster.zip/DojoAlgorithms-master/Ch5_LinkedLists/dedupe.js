/* Remove nodes with duplicate values. Following this call, all remaining nodes should have unique values. Retain only first isntance of each value. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SList() {
    this.head = null;
}

SList.prototype.dedupe = function() {
    var dupes = [];
    var runner = this.head;
    dupes.push(runner.val);

    function isInArr(val, arr) {
        for (var i = 0; i < arr.length; i++) {
            if (val === arr[i]) {
                return true;
            }
        }
        return false;
    }

    while (runner.next) {
        if (isInArr(runner.next.val, dupes)) {
            runner.next = runner.next.next;
        } else {
            dupes.push(runner.next.val);
        }
        runner = runner.next;
    }
    return this;
}