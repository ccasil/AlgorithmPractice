/* Create a function that removes the last ListNode in the list and returns the new list */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SLList() {
    this.head = null;
}

SLList.prototype.removeBack = function() {
    var runner = this.head;
    while (runner.next) {
        if (runner.next.next === null) {
            runner.next = null;
            return this;
        }
        runner = runner.next;
    }
    return this;
}