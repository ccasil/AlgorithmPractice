/* Remove the head node and return the new list head node. If list is empty, return null */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SLList() {
    this.head = null;
}

SLList.prototype.removeFront = function() {
    this.head = this.head.next;
    return this.head;
}