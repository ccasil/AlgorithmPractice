/* Create prependVal(val, before) to insert a new ListNode with val immediately before the node containing before (or at end if no node contains before). Return the new list. */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SLList() {
    this.head = null;
}

SLList.prototype.prependVal = function(val, before) {
    var newNode = new ListNode(val);
    var runner = this.head;
    if (runner.val === before) { // if before is at the head
        newNode.next = runner;
        this.head = newNode;
        return this;
    } else {
        while (runner.next) {
            if (runner.next.val === before) { // else, find before in the list
                newNode.next = runner.next;
                runner.next = newNode;
                return this;
            }
            runner = runner.next;
        }
        runner.next = newNode; // if before was not in the list, add newNode to end of list
        return this;
    }
}