/* Create a method removeSelf for a SLNode to disconnect (remove) itself from linked lists that include it. Note: the node might be the first in a list (but it won't be the last) and you do NOT have a pointer to the previous node. Also, don't lose any subseqwuent nodes pointed to by .next. */ 

function SLNode(value) {
    this.val = value;
    this.next = null;
}

SLNode.prototype.removeSelf = function() {
    this.val = this.next.val;
    this.next = this.next.next;
}