/* Create removeVal(val) to remove the node with the given val, and return the new list. If val is not found, prompt for a new val and run the function again */

function ListNode(value) {
    this.val = value;
    this.next = null;
}

function SLList() {
    this.head = null;
}

SLList.prototype.removeVal = function(val) {
    var runner = this.head;
    while (runner.next) {
        if (runner.next.val = val) {
            runner.next = runner.next.next;
            return this;
        }
        runner = runner.next;
    }
    var newVal = prompt('Value not found. Enter new value.');
    this.removeVal(newVal);
}