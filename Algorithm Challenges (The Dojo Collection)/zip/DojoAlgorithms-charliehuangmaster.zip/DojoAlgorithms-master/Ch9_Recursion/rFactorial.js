/* Given num, return the product of integers from 1 up to num. If less than zero, treat as zero. If not integer, truncate. Experts tell us 0! is 1. */

function rFact(num) {
    num = Math.trunc(num);
    if (num < 0) {
        return 0;
    }
    if (num === 0) {
        return 1;
    }
    return rFact(num - 1)*num;
}

console.log(rFact(3));
console.log(rFact(6.5));