/* Given a string containing chars '0', '1', and '?', for every '?', eitehr '0' or '1' can be substituted. Write a recursive function to return an array of all valid strings with '?' chars expanded to '0' or '1'.

e.g. binStrExpand("1?0?") returns ["1000", "1001", "1100", "1101"] */

function binStrExpand(str) {
    var output = [];
    rExpand(str, output, 0, [], 0);
    return output;

    function rExpand(str, output, index, temp, outputLength) {
        if (str.length === 1) {
            if (str[0] === "?") {
                output.push("0");
                output.push("1");
            } else {
                output.push(str[0]);
            }
        } else {
            if (index === 0) {
                rExpand(str.slice(1), output, 0, [], 0);
                outputLength = output.length;
            }
            if (index < outputLength) {
                temp.push(output.shift());
                if (str[0] === "?") {
                    output.push("0" + temp[index]);
                    output.push("1" + temp[index]);
                } else {
                    output.push(str[0] + temp[index]);
                }
                rExpand(str, output, index+1, temp, outputLength);
            }
        }
    }
}

console.log(binStrExpand("0"));
console.log(binStrExpand("?"));
console.log(binStrExpand("1?0?"));