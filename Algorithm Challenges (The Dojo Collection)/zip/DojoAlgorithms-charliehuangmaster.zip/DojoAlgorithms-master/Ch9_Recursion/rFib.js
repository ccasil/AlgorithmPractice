/* Recusively compute and return the num-th Fibonacci value. Treat the first two (num = 0, num = 1) Fibonacci values as 0 and 1. */

function rFib(num) {
    num = Math.trunc(num);
    if (num <= 0) {
        return 0;
    }
    if (num === 1) {
        return 1;
    }
    return rFib(num - 1) + rFib(num - 2);
}

console.log(rFib(2));
console.log(rFib(3.65));
console.log(rFib(5));
console.log(rFib(-2));