function zib(num) {
    num = Math.trunc(num);
    if (num <= 1) {
        return 1;
    }
    if (num === 2) {
        return 2;
    }
    if (num % 2 != 0) {
        var n = (num - 1)/2;
        return zib(n) + zib(n - 1) + 1;
    } else {
        var n = num/2;
        return zib(n) + zib(n + 1) + 1;
    }
}

function bestZibNum(num) {
    var largestIndex = 0;
    for (var i = num; i >= 1; i--) {
        if (zib(i) === num) {
            return i;
        }
    }
    return null;
}

console.log(bestZibNum(3186));
console.log(bestZibNum(3183));