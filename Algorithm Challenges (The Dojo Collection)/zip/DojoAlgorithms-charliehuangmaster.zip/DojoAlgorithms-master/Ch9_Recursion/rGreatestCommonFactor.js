/*
Given two integers, create a function to recursively determine their greatest common factor (the largest integer dividing evenly into both). 
    gcf(a,b) == a, if a == b;
    gcf(a,b) == gcf(a - b, b), if a > b;
    gcf(a,b) == gcf(a, b - a), if b > a;
*/

function rGCF(num1, num2) {
    if (num1 === num2) {
        return num1;
    }
    if (num1 > num2) {
        return rGCF(num1 - num2, num2);
    }
    if (num1 < num2) {
        return rGCF(num1, num2 - num1);
    }
}

console.log(rGCF(18, 24));
console.log(rGCF(18, 25));