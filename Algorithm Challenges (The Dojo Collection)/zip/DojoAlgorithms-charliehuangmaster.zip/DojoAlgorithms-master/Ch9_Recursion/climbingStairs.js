/* Given an integer, find all ways of summing to that integer using only 1s and 2s recursively WITHOUT LOOPS.
e.g. Given 4, return [[1,1,1,1], [1,1,2], [1,2,1], [2,1,1], [2,2]] */

/* VERSION WITH LOOPS */
// function climbingStairs(num) {
//     var dict = {0: [], 1: [[1]]};
//     if (num < 2) {
//         return dict[num];
//     } else {
//         rStairCombos(num, dict);
//         return dict[num];
//     }

//     function rStairCombos(num, dict) {
//         if (!dict[num-2]) {
//             rStairCombos(num-2, dict);
//         }
//         if (!dict[num-1]) {
//             rStairCombos(num-1, dict);
//         }

//         dict[num] = [];
//         var old1 = dict[num-2];
//         var old2 = dict[num-1];
        
//         if (old1.length === 0) {
//             dict[num].push([2]);
//         }
//         for (var i = 0; i < old2.length; i++) {
//             if (i < old1.length) {
//                 var temp1 = old1[i].slice(0);
//                 temp1[temp1.length] = 2;
//                 dict[num].push(temp1);
//             }
//             var temp2 = old2[i].slice(0);
//             temp2[temp2.length] = 1;
//             dict[num].push(temp2);
//         }
//     }
// }

/* VERSION WITHOUT LOOPS */
function climbingStairs(num) {
    var dict = {0: [], 1: [[1]]};
    if (num < 2) {
        return dict[num];
    } else {
        rStairCombos(num, dict, 0, dict[num-2], dict[num-1]);
        return dict[num];
    }

    function rStairCombos(num, dict, index, old1, old2) {
        if (!dict[num-2]) {
            rStairCombos(num-2, dict, 0, dict[num-4], dict[num-3]);
            old1 = dict[num-2];
        }
        if (!dict[num-1]) {
            rStairCombos(num-1, dict, 0, dict[num-3], dict[num-2]);
            old2 = dict[num-1];
        }

        if (index === 0) {
            dict[num] = [];
            if (old1.length === 0) {
                dict[num].push([2]);
            }
        }
        
        if (index < old2.length) {
            if (index < old1.length) {
                var temp1 = old1[index].slice(0);
                temp1[temp1.length] = 2;
                dict[num].push(temp1);
            }
            var temp2 = old2[index].slice(0);
            temp2[temp2.length] = 1;
            dict[num].push(temp2);
            rStairCombos(num, dict, index+1, dict[num-2], dict[num-1])
        }
    }
}

console.log(climbingStairs(2));
console.log(climbingStairs(3));
console.log(climbingStairs(4));
console.log(climbingStairs(5));