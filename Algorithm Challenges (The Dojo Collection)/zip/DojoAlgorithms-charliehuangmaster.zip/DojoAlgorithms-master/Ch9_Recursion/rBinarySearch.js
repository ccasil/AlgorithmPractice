/* Given a sorted array and a value, recursively determine if the value is found within the array. */

function rBinarySearch(arr, val) {
    if (arr.length < 1 || (arr.length === 1 && arr[0] !== val)) {
        return false;
    }

    var left = 0;
    var right = arr.length - 1;
    var middle = Math.floor((left + right)/2);

    if (val === arr[middle]) {
        return true;
    } else if (val > arr[middle]) {
        return rBinarySearch(arr.slice(middle+1), val);
    } else {
        return rBinarySearch(arr.slice(0, middle), val);
    }
}

console.log(rBinarySearch([1,2,3,4,5,6,7], 6));
console.log(rBinarySearch([1,2,3,4,5,6,7], 2));
console.log(rBinarySearch([1,2,3,4,5,6,7], 10));
console.log(rBinarySearch([1,3,5,6], 4));
console.log(rBinarySearch([4,5,6,8], 5));