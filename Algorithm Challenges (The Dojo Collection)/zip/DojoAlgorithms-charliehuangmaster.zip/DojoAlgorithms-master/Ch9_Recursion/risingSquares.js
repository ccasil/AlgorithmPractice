/* Given a positive integer, successively print squares of integers up to that integer, first ascending odds, then desscending evens. Solve recursively with no loops.

e.g. risingSquares(5) returns 1, 9, 25, 16, 4.
e.g. risingSquares(8) returns 1, 9, 25, 49, 64, 36, 16, 4. */

function risingSquares(num) {
    var squares = [];
    getSquares(num, 1, squares);
    return squares.join(", ");

    function getSquares(num, x, squares) {
        if (x > num) {
            getSquares(num, x-1, squares);
        } else if (x === 0) {
            return;
        } else {
            squares.push(Math.pow(x,2));
            if (x === num) {
                if (num % 2 == 0) {
                    getSquares(num, -1*(x-2), squares);
                } else {
                    getSquares(num, -1*(x-1), squares);
                }
            } else {
                getSquares(num, x+2, squares);
            }
        }
    }
}

console.log(risingSquares(5));
console.log(risingSquares(8));