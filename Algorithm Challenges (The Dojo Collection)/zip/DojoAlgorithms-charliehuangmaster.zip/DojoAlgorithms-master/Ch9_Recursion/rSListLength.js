/* Given the first node of a singly linked list, create a recursive function that returns the number of nodes in that list. Assume the list contains no loops and is short enough that you will not "blow your stack" */

function rSListLength(node) {
    var length = 0;
    updateLength(node, length);
    return length;

    function updateLength(node, length) {
        if (node) {
            length++;
            updateLength(node.next, length);
        } else {
            return;
        }
    }
}