/* Given a 7-digit phone number, return an array of all possible strings that equate to that phone number. For reference, the phone keypad mapping is:

[0: O, 1: I, 2: ABC, 3:DEF, 4: GHI, 5: JKL, 6: MNO, 7: PQRS, 8: TUV, 9: WXYZ]

For example, given 816-2612, return an array of 243 different strings, including "vitamic" and "titania". */

function telWords(str) {
    str = str.split("-").join("");
    if (str.length !== 7) {
        return null;
    }
    var map = {
        '0': 'O',
        '1': 'I',
        '2': 'ABC',
        '3': 'DEF',
        '4': 'GHI',
        '5': 'JKL',
        '6': 'MNO',
        '7': 'PQRS',
        '8': 'TUV',
        '9': 'WXYZ'
    }
    var strArr = [];
    getSubStrs(str, strArr, map);
    return strArr;
}

function getSubStrs(str, strArr, map) {
    if (str.length === 1) {
        var letters = map[str[0]];
        for (var i = 0; i < letters.length; i++) {
            strArr.push(letters[i]);
        }
    } else {
        getSubStrs(str.slice(1), strArr, map);
        var oldArr = [];
        while (strArr.length > 0) {
            oldArr.push(strArr.pop());
        }
        var letters = map[str[0]];
        for (var i = 0; i < letters.length; i++) {
            for (var j = 0; j < oldArr.length; j++) {
                strArr.push(letters[i] + oldArr[j]);
            }
        }
    }
}

console.log(telWords("816-2612").length);