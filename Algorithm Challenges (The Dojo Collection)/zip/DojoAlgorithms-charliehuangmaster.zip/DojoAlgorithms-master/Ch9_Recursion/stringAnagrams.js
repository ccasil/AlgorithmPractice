/* Given a string, return an array where each element is a string representing a different anagram.

e.g. strAna("lim") returns ["ilm", "iml", "lim, "lmi", "mil", "mli"] */

function strAna(str) {
    var output = [];
    rAna(str, output, 0, [], 0);
    return output;

    function rAna(str, output, index, temp, outputLength) {
        if (str.length === 1) {
            output.push(str[0]);
        } else {
            if (index === 0) {
                rAna(str.slice(1), output, 0, [], 0);
                outputLength = output.length;
            }
            if (index < outputLength) {
                temp.push(output.shift());
                for (var i = 0; i <= temp[index].length; i++) {
                    var subStr = temp[index].split("");
                    subStr.splice(i, 0, str[0]);
                    output.push(subStr.join(""));
                }
                rAna(str, output, index+1, temp, outputLength);
            }
        }
    }
}

console.log(strAna("lim"));
console.log(strAna("slim"));