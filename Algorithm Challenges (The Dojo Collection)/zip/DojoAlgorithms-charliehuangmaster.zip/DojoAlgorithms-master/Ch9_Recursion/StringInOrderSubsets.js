/* Create a function that returns an array with every possible in-order character subset of str. The resultant array itself need not be in any specific order, but the subset of letters in each string must be in the same order as they were in the original string.

Given "abc", return an array that includes ["", "c", "b", "bc", "a", "ac", "ab", "abc"] (in any order). */

function strSubsets(str) {
    var result = [];
    getSubsets(str, result);
    return result;

    function getSubsets(str, result) {
        if (str === "") {
            result.push("");
            return;
        }
        getSubsets(str.substring(1), result);
        var resultLength = result.length;
        for (var i = 0; i < resultLength; i++) {
            result.push(str[0] + result[i]);
        }
    }
}

console.log(strSubsets("abc"));