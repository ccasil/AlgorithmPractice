/* Write a recursive function that given a number returns the sum of integers from 1 to that number. */

function rSigma(num) {
    num = Math.floor(num);
    if (num < 1) {
        return 0;
    }
    if (num === 1) {
        return 1;
    }
    return rSigma(num - 1) + num;
}

console.log(rSigma(5));
console.log(rSigma(2.5));