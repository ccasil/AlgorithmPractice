/* There are a numer of baggies containing grapes, all in a row. Martin can take as many baggies as he wants, as long as he doesn't take two that are next to each other. Create a function that accepts an array of non-negative integers representing number of grapes in each adjacent baggy, and return the maximum amount of grapes that can be obtained. */

function maxGrapes(arr) {
    var maxSum = 0;
    return maxSumSub(arr, maxSum);;

    function maxSumSub(arr, maxSum) {
        if (arr.length === 0) {
            return 0;
        } else if (arr.length === 1) {
            return arr[0];
        } else {
            var sum1 = arr[0] + maxSumSub(arr.slice(2), maxSum);
            var sum2 = arr[1] + maxSumSub(arr.slice(3), maxSum);
            if (sum1 >= sum2) {
                maxSum += sum1;
            } else {
                maxSum += sum2;
            }
            return maxSum;
        }
    }
}

console.log(maxGrapes([2,4,3,5,8]));
console.log(maxGrapes([1,1,1,3,1]));
console.log(maxGrapes([1,10,9,0,1]));