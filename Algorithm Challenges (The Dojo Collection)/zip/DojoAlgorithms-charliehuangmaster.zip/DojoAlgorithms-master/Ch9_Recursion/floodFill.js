/* Build floodFill(canvas2D, startXY, newColor). Repalce a pixel's color value only if it is the same color as the origin coordinate and is directly adjacent via X or Y to another pixel you will change. Diagnally related pixels are not considered adjacent. */

function floodFill(canvas2D, startXY, newColor) {
    var xLength = canvas2D[0].length;
    var yLength = canvas2D.length;

    var currentX = startXY[0];
    var currentY = startXY[1];
    var startingColor = canvas2D[currentY][currentX];
    canvas2D[currentY][currentX] = newColor;

    var adjacent = [];
    if (currentY - 1 >= 0) { // top
        adjacent.push([currentX, currentY - 1]);
    }
    if (currentX + 1 < xLength) { // right
        adjacent.push([currentX + 1, currentY]);
    }
    if (currentY + 1 < yLength) { // bottom
        adjacent.push([currentX, currentY + 1]);
    }
    if (currentX - 1 >= 0) { // left
        adjacent.push([currentX - 1, currentY]);
    }

    for (var i = 0; i < adjacent.length; i++) {
        var adjacentX = adjacent[i][0];
        var adjacentY = adjacent[i][1];
        if (canvas2D[adjacentY][adjacentX] === startingColor) {
            floodFill(canvas2D, adjacent[i], newColor);
        }
    }
}

var canvas2D = [
    [3,2,3,4,3],
    [2,3,3,4,0],
    [7,3,3,5,3],
    [6,5,3,4,1],
    [1,2,3,3,3]
];
floodFill(canvas2D, [2,2], 1);
console.log(canvas2D);