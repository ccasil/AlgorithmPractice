/* Given an integer, calculate and print all combinations of square integers that sum to that integer. No duplicates are allowed among smaller integers. Solve recursively with no loops. 

e.g. sumOfSquares(30) returns "1 + 4 + 25, 1 + 4 + 9 + 16" */

function sumOfSquares(num) {
    var output = [];
    var highestInt = Math.floor(Math.sqrt(num));
    callrSums(num, output, 1, highestInt);
    return output.join(", ");

    function callrSums(num, output, index, highestInt) {
        if (index <= highestInt) {
            rSums(num, output, index, highestInt, []);
            callrSums(num, output, index+1, highestInt);
        }
    }

    function rSums(num, output, index, highestInt, temp) {
        if (index <= highestInt && index > 0) {
            var nextSquare = Math.pow(index, 2);
            temp.push(nextSquare);
            if (nextSquare < num) {
                rSums(num - nextSquare, output, index+1, highestInt, temp);
            } else {
                if (nextSquare === num) {
                    output.push(temp.join(" + "));
                }
                temp.pop();
                num += temp.pop();
                if (temp.length > 0) {
                    rSums(num, output, index, highestInt, temp);
                }
            }
        }
    }
    
    // function callrSums(num, output, startInd, highestInt) {
    //     if (startInd <= highestInt) {
    //         rSums(num, output, startInd, startInd+1, highestInt, []);
    //         callrSums(num, output, startInd+1, highestInt);
    //     }
    // }

    // function rSums(num, output, startInd, index, highestInt, temp) {
    //     if (startInd <= highestInt) {
    //         var nextSquare = Math.pow(startInd, 2);
    //         temp.push(nextSquare);
    //         if (nextSquare === num) {
    //             output.push(nextSquare);
    //             temp.pop();
    //         } else if (nextSquare > num) {
    //             temp.pop();
    //         } else {
    //             if (index > 0 && index <= highestInt) {
    //                 var nextSquare2 = Math.pow(index, 2);
    //                 temp.push(nextSquare2);
    //                 if (nextSquare2 === num) {
    //                     output.push(temp.join(" + "));
    //                     temp.pop();
    //                     num += temp.pop();
    //                     if (temp.length > 0) {
    //                         rSums(num, output, startInd, index-1, highestInt, temp);
    //                     }
    //                 } else if (nextSquare > num) {
    //                     temp.pop();
    //                     num += temp.pop();

    //                 }
    //             }
    //         }



    //         if (index > 0 && index <= highestInt) {
    //             var nextSquare = Math.pow(index, 2);
    //             temp.push(nextSquare);
    //             if (nextSquare === num) {
    //                 output.push(temp.join(" + "));
    //                 temp.pop();
    //                 num += temp.pop();
    //                 if (temp.length > 0) {
    //                     rSums(num, output, startInd, index-1, highestInt, temp);
    //                 }
    //             } else if (nextSquare > num) {
    //                 temp.pop();
    //                 num += temp.pop();
    //                 if (temp.length > 0) {
    //                     rSums(num, output, startInd, index, highestInt, temp);
    //                 }
    //             } else {
    //                 rSums(num - nextSquare, output, startInd, index+1, highestInt, temp);
    //             }
    //         }
    //         rSums(num, output)
    //     }
    // }

}

// console.log(sumOfSquares(5));
// console.log(sumOfSquares(10));
// console.log(sumOfSquares(13));
// console.log(sumOfSquares(25));
// console.log(sumOfSquares(29));
// console.log(sumOfSquares(30));
// console.log(sumOfSquares(36));
// console.log(sumOfSquares(40));
// console.log(sumOfSquares(55));
console.log(sumOfSquares(65));