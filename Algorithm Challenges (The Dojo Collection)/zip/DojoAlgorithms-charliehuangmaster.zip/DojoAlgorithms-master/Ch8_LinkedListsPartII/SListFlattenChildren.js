/* Each node has .next but also .child that is either null or points to another head. In turn, each child node could point to another list. Don't alter .child; arrange .next pointers to flatten the hierarchy inton one linear list, from head through all others via .next. */

function SLNode(value) {
    this.val = value;
    this.next = null;
    this.child = null;
}

SLNode.prototype.flattenChildren = function(node) {
    var list = new SList();
    list.head = node;
    var endOfList = list.head;
    var runner = node;
    var isHead = true;
    while (runner) {
        if (runner.child) {
            var runner2 = runner.child.head;
            while (runner2) {
                var newNode = new SLNode(runner2.val);
                endOfList.next = newNode;
                endOfList = endOfList.next;
            }
        }
        if (!isHead) {
            var newNode = new SLNode(runner.val);
            endOfList.next = newNode;
            endOfList = endOfList.next;
        }
        isHead = false;
        runner = runner.next;
    }
    return list;
}