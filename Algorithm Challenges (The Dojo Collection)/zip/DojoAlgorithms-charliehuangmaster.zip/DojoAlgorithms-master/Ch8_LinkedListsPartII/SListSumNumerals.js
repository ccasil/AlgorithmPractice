/* Given two lists, each representing a number. Every node value is a 0-9 digit, with the first node representing the least significant digit. Return a new list representing the sum. For example, given 2->0->1 and 8->4, return 0->5->1 because 102 + 48 = 150. */

function sumNumerals(list1, list2) {
    var sum = (numRepr(list1) + numRepr(list2)).toString();
    var sumList = new SLStack();
    for (var i = 0; i < sum.length; i++) {
        sumList.push(parseInt(sum[i]));
    }
    return sumList;

    function numRepr(list) {
        var listLength = 0;
        var runner = list.head;
        while (runner) {
            if (runner.val > 9) {
                console.log("Node values must be a 0-9 digit!");
                return null;
            }
            listLength++;
            runner = runner.next;
        }
        var numStr = "";
        runner = list.head;
        for (var i = 0; i < listLength; i++) {
            numStr = runner.val.toString() + numStr;
            runner = runner.next;
        }
        return parseInt(numStr);
    }
}