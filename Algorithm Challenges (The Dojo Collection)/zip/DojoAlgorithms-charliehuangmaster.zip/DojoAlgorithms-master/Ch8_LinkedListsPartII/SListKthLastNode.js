/* Given k, return the lvalue that is 'k' nodes from the list's end. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

SList.prototype.kthLastNode = function(k) {
    var length = 0;
    var runner = this.head;
    while (runner) {
        length++;
        runner = runner.next;
    }
    var end = length + 1 - k;
    runner = this.head;
    while (end > 0) {
        runner = runner.next;
        end--;
    }
    return runner.val;
}