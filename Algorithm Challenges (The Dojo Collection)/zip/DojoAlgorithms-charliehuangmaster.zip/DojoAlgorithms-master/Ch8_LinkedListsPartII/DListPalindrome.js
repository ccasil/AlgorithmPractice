/* Determine if a DList is a palindrome */

DList.prototype.isPalindrome = function() {
    var runner = this.head;
    var runner2 = this.tail;
    while (runner) {
        if (runner !== runner2) {
            return false;
        }
        runner = runner.next;
        runner2 = runner2.prev;
    }
    return true;
}