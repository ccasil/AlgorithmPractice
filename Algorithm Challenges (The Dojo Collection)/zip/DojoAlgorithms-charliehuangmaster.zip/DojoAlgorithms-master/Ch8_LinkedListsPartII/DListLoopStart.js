/* Given a Dlist that may contain a loop, return the node where the loop begins (or null if no loop) and break the loop. */

DList.prototype.loopStart = function() {
    var runner = this.head;
    while (runner.next) {
        if (runner.next.prev !== runner) {
            var temp = runner.next;
            runner.next = null;
            this.tail = runner;
            return temp;
        }
        runner = runner.next;
    }
    return null;
}