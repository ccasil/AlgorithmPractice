/* Construct the DList methods push() and pop() */

function DLNode(value) {
    this.val = value;
    this.prev = null;
    this.next = null;
}

function DList() {
    this.head = null;
    this.tail = null;
}

DList.prototype.push = function(value) {
    var newNode = new DLNode(value);
    this.tail.next = newNode;
    newNode.prev = this.tail;
    this.tail = newNode;
}

DList.prototype.pop = function() {
    var lastNode = this.tail;
    var secondToLast = this.tail.prev;
    secondToLast.next = null;
    this.tail = secondToLast;
    return lastNode;
}