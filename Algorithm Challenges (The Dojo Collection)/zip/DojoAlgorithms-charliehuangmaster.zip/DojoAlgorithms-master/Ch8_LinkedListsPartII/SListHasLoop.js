/* Given a linked list, determine if it has a loop and return a boolean accordingly */

SList.prototype.hasLoop = function() {
    var walker = this.head;
    var runner = this.head;
    while (walker) {
        if (!runner.next || !runner.next.next) {
            return false;
        }
        walker = walker.next;
        if (walker === runner.next.next) {
            this.breakLoop(meetingNode);
            return true;
        }
        runner = runner.next.next;
    }
}

SList.prototype.breakLoop = function(meetingNode) {
    var runner1 = this.head;
    var runner2 = meetingNode;
    while (runner1 !== runner2) {
        runner1 = runner1.next;
        runner2 = runner2.next;
    }
    while (runner2) {
        if (runner2.next === runner1) {
            runner2.next = null;
            break;
        }
        runner2 = runner2.next;
    }
}