/* Given a singly linked list, rearrange the nodes so that successive pairs of nodes are swapped in sequence. If the list has an odd number of nodes, the final node (not pair of a pair) should be unchanged. */

SList.prototype.swapPairs = function() {
    var runner = this.head;
    var prev = this.head;
    while (runner) {
        if (runner.next) {
            var temp = runner.next.next;
            runner.next.next = runner;
            prev.next = runner.next;
            prev = runner;
            runner.next = temp;
        }
        runner = runner.next;
    }
}