/* Reverse a doubly-linked list. */

function DLNode(value) {
    this.val = value;
    this.prev = null;
    this.next = null;
}

function DList() {
    this.head = null;
    this.tail = null;
}

DList.prototype.reverse = function() {
    this.tail = this.head;
    var current = this.tail;
    while (current) {
        var temp = current.prev;
        current.prev = current.next;
        current.next = temp;
        if (!current.prev) {
            this.head = current;
            break;
        }
        current = current.prev;
    }
}