/* Reverse the node sequence. Given an SList object. the head property should point to the previously-last node, and the rest of the nodes should follow similarly from back to front. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

SList.prototype.reverse = function() {
    var curr = this.head;
    while (curr.next) {
        var temp = curr.next.next;
        var prev = curr.next;
        curr.next = temp;
        prev.next = this.head;
        this.head = prev;
    }
    return this;
}

/* function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
} */

/* SList.prototype.reverse = function() {
    var reversed = new SLStack();
    var runner = this.head;
    var counter = 0;
    while (runner) {
        reversed.push(runner);
        runner = runner.next;
        counter++;
    }
    this.head = null;
    while (counter > 0) {
        this.addBack(reversed.pop());
        counter--;
    }
    return this;
} */