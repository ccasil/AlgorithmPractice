/* Return if a list is a palindrome by comparing SLNode values */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

SList.prototype.isPalindrome = function() {
    var length = 0;
    var runner = this.head;
    while (runner) {
        length++;
        runner = runner.next;
    }
    var index = 0;
    var end = length - index;
    var runner2 = this.head;
    while (index <= length/2) {
    runner = this.head;
        while (end > 0) {
            runner = runner.next;
            end--;
        }
        if (runner.val !== runner2.val) {
            return false;
        } else {
            runner2 = runner2.next;
            index++;
            end = length - index;
        }
    }
    return true;
}