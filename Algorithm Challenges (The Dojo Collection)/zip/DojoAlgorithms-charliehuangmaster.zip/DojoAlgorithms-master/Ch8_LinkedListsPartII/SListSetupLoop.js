/* Create a sequence of SLNodes that form a closed loop. The function's first argument should signify how many nodes total, and the second should be which node number is pointed to by the last node. Give nodes sequential numbers as values, for clarity. Calling setupLoop(5, 3) should return a circular list of 1>2>3>4>5>3>4>5>3>4>5>3... */

function setupLoop(length, pointedTo) {
    var list = new SLQueue();
    for (var i = 1; i <= length; i++) {
        list.enqueue(i);
    }
    var runner = list.head;
    for (var i = 1; i < pointedTo; i++) {
        runner = runner.next;
    }
    list.tail.next = runner;
    return list;
}