def bubble_sort(ls):
    if len(ls) < 2:
        return ls
    sorted = False
    while not sorted:
        sorted = True
        x = 0
        for i in range(0, len(ls)-1-x):
            if ls[i] > ls[i+1]:
                ls[i], ls[i+1] = ls[i+1], ls[i]
                sorted = False
        x += 1
    return ls

print bubble_sort([4,6,32,6,8,3,1,5])