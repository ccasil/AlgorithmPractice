def insertion_sort(ls):
    if len(ls) < 2:
        return ls
    for i in range(1, len(ls)):
        j = i - 1
        temp = ls[i]
        while j >= 0 and ls[j] > temp:
            ls[j+1] = ls[j]
            j -= 1
        ls[j+1] = temp
    return ls

print insertion_sort([])
print insertion_sort([1])
print insertion_sort([3,-1])
print insertion_sort([5,32,6,9,6,90,4,1,6,9,5])