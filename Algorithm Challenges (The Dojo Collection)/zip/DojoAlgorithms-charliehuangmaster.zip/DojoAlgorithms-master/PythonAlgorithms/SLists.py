class SLNode(object):
    def __init__(self, val):
        self.val = val
        self.next = None

class SList(object):
    def __init__(self):
        self.head = None
        self.next = None

    def print_all_vals(self):
        vals = []
        runner = self.head
        while runner != None:
            vals.append(runner.val)
            runner = runner.next
        print ' -> '.join(vals)
        return self

    def add_back(self, val):
        if self.head == None:
            self.head = SLNode(val)
        else:
            runner = self.head
            while runner.next != None:
                runner = runner.next
            runner.next = SLNode(val)
        return self

    def add_front(self, val):
        if self.head == None:
            self.head = SLNode(val)
        else:
            temp = self.head
            self.head = SLNode(val)
            self.head.next = temp
        return self

    def insert_before(self, nextVal, val):
        if self.head == None:
            self.head = SLNode(val)
        elif self.head.val == nextVal:
            self.add_front(val)
        else:
            runner = self.head
            while runner.next:
                if runner.next.val == nextVal:
                    temp = runner.next
                    runner.next = SLNode(val)
                    runner.next.next = temp
                    return self
                else:
                    runner = runner.next
            print 'nextVal does not exist'
        return self

    def insert_after(self, prevVal, val):
        if self.head == None:
            self.head = SLNode(val)
        else:
            runner = self.head
            while runner:
                if runner.val == prevVal:
                    temp = runner.next
                    runner.next = SLNode(val)
                    runner.next.next = temp
                    return self
                else:
                    runner = runner.next
            print 'prevVal does not exist'
        return self

    def remove_node(self, val):
        if self.head == None:
            print 'node cannot be removed from empty list'
        elif self.head.val == val:
            self.head = self.head.next
        else:
            runner = self.head
            while runner.next:
                if runner.next.val == val:
                    runner.next = runner.next.next
                    return self
                else:
                    runner = runner.next
            print 'node was not found in list'
        return self

    def reverse_list(self):
        if self.head == None or self.head.next == None:
            return self
        reversed_ls = SList()
        length = 0
        runner = self.head
        while runner:
            length += 1
            runner = runner.next
        count = 1
        while length > 0:
            runner = self.head
            while count < length:
                runner = runner.next
                count += 1
            reversed_ls.add_back(runner.val)
            length -= 1
            count = 1
        self.head = reversed_ls.head
        return self


list = SList()
list.head = SLNode('Alice')
list.head.next = SLNode('Chad')
list.head.next.next = SLNode('Debra')
list.add_back('George')
list.add_front('First')
list.insert_before('First', 'Zero')
list.insert_before('Debra', 'BeforeDebra')
list.insert_before('Alex', 'Somebody')
list.insert_after('Debra', 'AfterDebra')
list.insert_after('George', 'Last')
list.print_all_vals()
list.remove_node('Alex')
list.remove_node('Zero')
list.remove_node('Chad')
list.remove_node('Last')
list.print_all_vals()
list.reverse_list()
list.print_all_vals()