def selection_sort(ls):
    if len(ls) < 2:
        return ls
    for i in range(0, len(ls)-1):
        min_i = min_index(ls, i)
        ls[i], ls[min_i] = ls[min_i], ls[i]
    return ls

def min_index(ls, start):
    min_val = ls[start]
    min_index = start
    for i, num in enumerate(ls[start:], start):
        if num < min_val:
            min_val = num
            min_index = i
    return min_index

print selection_sort([])
print selection_sort([1])
print selection_sort([2,1])
print selection_sort([67,43,21,5,78,23,1,4,8,4,2])