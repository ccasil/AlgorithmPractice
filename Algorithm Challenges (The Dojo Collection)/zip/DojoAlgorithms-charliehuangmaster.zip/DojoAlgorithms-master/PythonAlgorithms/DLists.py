class DLNode(object):
    def __init__(self, val):
        self.val = val
        self.prev = None
        self.next = None

class DList(object):
    def __init__(self):
        self.head = None
        self.next = None
    
    def print_all_vals(self):
        vals = []
        runner = self.head
        while runner:
            vals.append(runner.val)
            print 'Val: {}, Prev: {}, Next: {}'.format(runner, runner.prev, runner.next)
            runner = runner.next
        print " <-> ".join(vals)
    
    def add(self, val):
        if self.head == None:
            self.head = DLNode(val)
        else:
            runner = self.head
            while runner.next:
                runner = runner.next
            runner.next = DLNode(val)
            runner.next.prev = runner
        return self

    def delete(self, val):
        if self.head == None:
            print 'cannot delete from empty list'
        elif self.head.val == val:
            self.head = self.head.next
            self.head.prev = None
        else:
            runner = self.head
            while runner.next:
                if runner.next.val == val:
                    runner.next = runner.next.next
                    runner.next.prev = runner
                    return self
                else:
                    runner = runner.next
            print 'val not found in list'
        return self

    def insert_after(self, prevVal, val):
        if self.head == None:
            self.head = DLNode(val)
        else:
            runner = self.head
            while runner:
                if runner.val == prevVal:
                    if runner.next == None:
                        runner.next = DLNode(val)
                        runner.next.prev = runner
                    else:
                        temp = runner.next
                        runner.next = DLNode(val)
                        runner.next.prev = runner
                        runner.next.next = temp
                        temp.prev = runner.next
                    return self
                else:
                    runner = runner.next
            print 'val not found in list'
        return self

list = DList()
list.add('1')
list.add('2')
list.add('3')
list.add('4')
list.print_all_vals()
list.delete('0')
list.delete('2')
list.print_all_vals()
list.insert_after('0','3')
list.insert_after('3','3')
list.insert_after('4','5')
list.print_all_vals()