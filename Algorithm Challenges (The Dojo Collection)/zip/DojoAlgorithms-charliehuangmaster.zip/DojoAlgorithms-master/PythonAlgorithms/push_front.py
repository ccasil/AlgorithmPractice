def push_front(ls, val):
    ls.append(val)
    for i in range(len(ls)-1, 0, -1):
        ls[i], ls[i-1] = ls[i-1], ls[i]
    return ls
print push_front([1,2,3,4], 0)
print push_front([], 0)
print push_front([1], 0)