def change(cents):
    coins = {}
    coins['dollars'] = cents/100
    cents -= coins['dollars']*100
    coins['quarters'] = cents/25
    cents -= coins['quarters']*25
    coins['dimes'] = cents/10
    cents -= coins['dimes']*10
    coins['nickels'] = cents/5
    cents -= coins['nickels']*5
    coins['pennies'] = cents
    return coins

print change(387)