/*
Knight's Shortest Path:
Given a starting and ending location on a normal 8x8 chessboard (locations given as integers 0-63 starting at the top left corner, going left to right), find the fewest possible steps for a knight to travel from start to end.
*/

function KnightsShortestPath(start, end) {
    var grid = intsToGrid();
    var startCoords = grid[start];
    var endCoords = grid[end];
    
    // already visited
    var S = [];
    S.push(startCoords);

    var root = new Node(startCoords);

    // to visit
    var Q = [];
    Q.push(root);

    while (Q.length > 0) {
        var current = Q.shift();
        if (coordsAreEqual(current.value, endCoords)) {
            var endNode = current;
            break;
        }
        var neighbors = findNextCoords(current.value);
        // create new node for each new neighbor
        neighbors.forEach(function(coords) {
            if (alreadyVisited(coords, S) === false) {
                S.push(coords);
                var neighbor = new Node(coords);
                neighbor.parent = current;
                current.addNeighbor(neighbor);
                Q.push(neighbor);
            }
        });
    }
    
    // find the shortest path from end node to root node
    return findParentPath(endNode).length;
}


function intsToGrid() {
    var grid = {};
    var gridKey = 0;
    for (var row = 0; row <= 7; row++) {
        for (var col = 0; col <= 7; col++) {
            if (col < (row + 1)*8) {
                grid[gridKey] = [row, col];
                gridKey++;
            }
        }
    }
    return grid;
}

function coordsAreEqual(coords1, coords2) {
    return coords1[0] === coords2[0] && coords1[1] === coords2[1];
}

function isInGrid(coords) {
    return coords[0] >= 0 && coords[0] <= 7 && coords[1] >= 0 && coords[1] <= 7;
}

function findNextCoords(coords) {
    var nextCoords = [];
    if (isInGrid([coords[0]-2, coords[1]-1])) { // up left
        nextCoords.push([coords[0]-2, coords[1]-1]);
    }
    if (isInGrid([coords[0]-2, coords[1]+1])) { // up right
        nextCoords.push([coords[0]-2, coords[1]+1]);
    }
    if (isInGrid([coords[0]-1, coords[1]+2])) { // right up
        nextCoords.push([coords[0]-1, coords[1]+2]);
    }
    if (isInGrid([coords[0]+1, coords[1]+2])) { // right down
        nextCoords.push([coords[0]+1, coords[1]+2]);
    }
    if (isInGrid([coords[0]+2, coords[1]+1])) { // down right
        nextCoords.push([coords[0]+2, coords[1]+1]);
    }
    if (isInGrid([coords[0]+2, coords[1]-1])) { // down left
        nextCoords.push([coords[0]+2, coords[1]-1]);
    }
    if (isInGrid([coords[0]+1, coords[1]-2])) { // left down
        nextCoords.push([coords[0]+1, coords[1]-2]);
    }
    if (isInGrid([coords[0]-1, coords[1]-2])) { // left up
        nextCoords.push([coords[0]-1, coords[1]-2]);
    }
    return nextCoords;
}

function Node(value) {
    this.value = value;
    this.neighbors = [];
    this.parent = null;
    this.addNeighbor = function(neighbor) {
        this.neighbors.push(neighbor);
        neighbor.neighbors.push(this);
    }
}

function alreadyVisited(coords, visited) {
    for (var i = 0; i < visited.length; i++) {
        if (coordsAreEqual(coords, visited[i])) {
            return true;
        }
    }
    return false;
}

function findParentPath(endNode) {
    var path = [];
    var next = endNode.parent;
    while (next !== null) {
        path.push(next);
        next = next.parent;
    }
    return path;
}