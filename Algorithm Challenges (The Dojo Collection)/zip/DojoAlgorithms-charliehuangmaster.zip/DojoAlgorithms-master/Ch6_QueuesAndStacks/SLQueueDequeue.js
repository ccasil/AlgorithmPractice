/* Create a SLQueue method to remove and return the value at the front of the queue */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

SLQueue.prototype.dequeue = function() {
    if (!this.head) {
        return this;
    }
    var frontNode = this.head;
    frontNode.next = null;
    this.head = this.head.next;
    return frontNode;
}