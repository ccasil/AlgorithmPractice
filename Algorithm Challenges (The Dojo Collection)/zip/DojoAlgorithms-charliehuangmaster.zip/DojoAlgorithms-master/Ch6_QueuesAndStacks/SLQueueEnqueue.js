/* Create a SLQueue method to add a given value to the end of the queue */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

SLQueue.prototype.enqueue = function(val) {
    var newNode = new SLNode(val);
    if (!this.head) {
        this.head = newNode;
        this.tail = newNode;
    } else {
        this.tail.next = newNode;
        this.tail = newNode;
    }
}