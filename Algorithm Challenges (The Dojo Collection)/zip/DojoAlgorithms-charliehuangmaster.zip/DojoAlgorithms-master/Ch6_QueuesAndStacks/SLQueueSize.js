/* Create a SLQueue method that returns the number of values in the queue */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLQueue() {
    var head = null;
    var tail = null;
}

SLQueue.prototype.size = function() {
    var size = 0;
    var runner = this.head;
    while (runner) {
        size++;
        runner = runner.next;
    }
    return size;
}