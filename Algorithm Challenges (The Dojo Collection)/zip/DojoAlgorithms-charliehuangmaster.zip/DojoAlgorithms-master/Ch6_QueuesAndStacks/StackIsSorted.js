/* Given a stack containing numerical values, write a standalone function that returns a boolean to represent if the stack's values are sorted from smallest (at stack top) to largest (at stack bottom). */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function isSorted(stack) {
    var runner = stack.head;
    while (runner.next) {
        if (runner.next.val > runner.val) {
            return false;
        }
        runner = runner.next;
    }
    return true;
}