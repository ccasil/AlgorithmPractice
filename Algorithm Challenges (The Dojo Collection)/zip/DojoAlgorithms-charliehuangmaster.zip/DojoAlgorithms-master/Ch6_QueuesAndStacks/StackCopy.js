/* Given a stack, create a new second stack and copy values from the first stack into the second stack so that they pop in the same order. Use only one queue for additional storage. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

SLStack.prototype.copy = function() {
    var queue = new SLQueue();
    var runner = this.head;
    while (runner) {
        queue.enqueue(runner.val);
        runner = runner.next;
    }
    var copiedStack = new SLStack();
    runner = queue.head;
    while (runner) {
        copiedStack.push(runner.val);
        runner = runner.next;
    }
    return copiedStack;
}