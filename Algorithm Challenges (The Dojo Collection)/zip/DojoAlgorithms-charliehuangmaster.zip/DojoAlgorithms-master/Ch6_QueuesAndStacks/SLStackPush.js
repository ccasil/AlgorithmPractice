/* Create push(val) that adds val to the stack */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

SLStack.prototype.push = function(val) {
    var newNode = new SLNode(val);
    if (!this.head) {
        this.head = newNode;
        this.tail = newNode;
        return;
    }
    this.tail.next = newNode;
}