/* Create function that pushes a new node with the given value to the front of a Stack */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

SLStack.prototype.pushFront = function(val) {
    var newNode = new SLNode(val);
    if (!this.head) {
        this.head = newNode;
        this.tail = newNode;
        return;
    }
    newNode.next = this.head;
    this.head = newNode;
}