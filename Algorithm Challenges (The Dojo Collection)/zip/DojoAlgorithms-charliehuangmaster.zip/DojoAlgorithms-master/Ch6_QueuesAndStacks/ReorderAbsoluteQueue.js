/* Create a standalone function that acceptss a queue of numbers sequenced in absolute value order such as (10, -20, 30, -40, 50). Using only an additional queue for storage, reorder the queue values so that they are in increasing order, such as (-40, -20, 10, 30, 50). */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

function reorder(queue) {
    var q2 = new SLQueue();

    // remove negatives from front and push to storage stack
    var runner = queue.head;
    while (runner) {
        if (runner.val >= 0) {
            break;
        } else {
            q2.enqueue(runner.val);
            queue.head = runner.next;
        }
        runner = queue.head;
    }

    // run through rest of queue, remove negatives and push to storage stack
    runner = queue.head;
    while (runner.next) {
        if (runner.next.val < 0) {
            Q2.enqueue(runner.next);
            runner.next = runner.next.next;
        } else {
            runner = runner.next;
        }
    }

    // add negative values from storage queue back to front of original queue
    runner = q2.head;
    while (runner) {
        var temp = q2.dequeue();
        queue.enqueueFront(temp);
        runner = q2.head;
    }

    // reset head and tail of original queue
    queue.head = temp;
    runner = queue.head;
    while (runner.next) {
        runner = runner.next;
    }
    queue.tail = runner;
    return queue;
}