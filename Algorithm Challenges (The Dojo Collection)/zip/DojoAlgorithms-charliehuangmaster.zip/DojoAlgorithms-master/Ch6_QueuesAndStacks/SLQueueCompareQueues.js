/* Given two SLQueue objects, create a standalone function that returns if they are equal. Queues are equal only if they have equal elements in identical order. Allocate no other object and return the queues in their original condition upon exit */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLQueue() {
    var head = null;
    var tail = null;
}

function areQueuesEqual(q1, q2) {
    var runner1 = q1.head;
    var runner2 = q2.head;
    while (runner1 && runner2) {
        if (runner1.val !== runner2.val) {
            return false;
        }
        runner1 = runner1.next;
        runner2 = runner2.next;
    }
    if (runner1 || runner2) {
        return false;
    } else {
        return true;
    }
}