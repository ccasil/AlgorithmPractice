/* Given a stack containing integers, switch successive pairs of values starting at the top of the stack. If there is an odd number of values, the bottom value is unaffected. For example, (1,2,3,4,5,6,7) should become (1,3,2,5,4,7,6). Use only one additional stack for storage. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

SLStack.prototype.switchPairs = function() {
    var stack = new SLStack();
    var oldHead = this.head;
    var isOldHead = false;
    while (oldHead.next) {
        stack.push(this.pop());
        stack.push(this.pop());
        this.pushFront(stack.pop());
        if (this.head === oldHead) {
            isOldHead = true;
        }
        this.pushFront(stack.pop());
        if (isOldHead) {
            break;
        }
    }
    if (!oldHead.next) {
        this.pushFront(this.pop());
    }
    var runner = this.head;
    while (runner.next) {
        runner = runner.next;
    }
    this.tail = runner;
    return this;
}