/* Given a queue, return true if its values are a palindrome, else return false. Restore the queue to its original state before exiting. For storage, use one additional stack. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

function isQueuePalindrome(queue) {
    var storageStack = new SLStack();
    var runner = queue.head;
    while (runner) {
        storageStack.push(runner.val);
        runner = runner.next;
    }
    return areQueuesEqual(queue, storageStack);
}

function areQueuesEqual(q1, q2) {
    var runner1 = q1.head;
    var runner2 = q2.head;
    while (runner1 && runner2) {
        if (runner1.val !== runner2.val) {
            return false;
        }
        runner1 = runner1.next;
        runner2 = runner2.next;
    }
    if (runner1 || runner2) {
        return false;
    } else {
        return true;
    }
}