/* Create a SLQueue method that returns whether a given value is found within the queue */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLQueue() {
    var head = null;
    var tail = null;
}

SLQueue.prototype.contains = function(val) {
    var runner = this.head;
    while (runner) {
        if (runner.val === val) {
            return true;
        }
        runner = runner.next;
    }
    return false;
}