/* Mirror a stack's exisiting values onto itself, in reverse. Given (1,3,5,7) should be returned (1,3,5,7,7,5,3,1). */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function mirror(stack) {
    var storage = new SLStack();
    var runner = stack.head;
    while (runner) {
        storage.push(runner.val);
        runner = runner.next;
    }
    while (storage.head) {
        stack.push(storage.pop());
    }
    return stack;
}