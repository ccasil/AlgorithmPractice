/* Remove a stack's minimum  value, otherwise leaving values in order. If duplicate min values are found, remove them all. Use only one additional queue for storage. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

function SLQueue() {
    this.head = null;
    this.tail = null;
}

SLStack.prototype.removeMin = function() {
    var min = this.head.val;
    var runner = this.head.next;
    while (runner) {
        if (runner.val < min) {
            min = runner.val;
        }
        runner = runner.next;
    }
    var storageArr = [];
    runner = this.head;
    while (runner) {
        if (runner.val !== min) {
            storageArr.push(runner.val);
        }
        runner = runner.next;
    }
    this.head = null;
    this.tail = null;
    for (var i = storageArr.length-1; i >= 0; i--) {
        this.push(storageArr[i]);
    }
    return this;
}