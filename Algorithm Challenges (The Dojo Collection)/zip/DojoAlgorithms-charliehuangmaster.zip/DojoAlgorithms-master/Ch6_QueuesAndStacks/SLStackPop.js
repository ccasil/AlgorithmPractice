/* Create pop() to remove and return the top val. */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    this.head = null;
    this.tail = null;
}

SLStack.prototype.pop = function() {
    if (!this.head) {
        return;
    }
    if (this.head == this.tail) {
        var temp = this.head;
        this.head = null;
        this.tail = null;
        return temp;
    }
    var runner = this.head;
    while (runner.next) {
        if (runner.next == this.tail) {
            var temp = runner.next;
            temp.next = null;
            this.tail = runner;
            runner.next = null;
            return temp;
        }
        runner = runner.next;
    }
}