/* Given two Stack objects, creat a standalone function to return if they are equal. Stacks are equal only if they have equal elements in identical order */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLStack() {
    var head = null;
}

function compareStacks(s1, s2) {
    var runner1 = s1.head;
    var runner2 = s2.head;
    while (runner1 && runner2) {
        if (runner1.val !== runner2.val) {
            return false;
        }
        runner1 = runner1.next;
        runner2 = runner2.next;
    }
    if (runner1 || runner2) {
        return false;
    } else {
        return true;
    }
}