/* Create a standalone function to remove a queue's lowest value, otherwise leaving values in the same sequence. Use only local variables; allocate no other objects. Remove all duplicates of this value */

function SLNode(value) {
    this.val = value;
    this.next = null;
}

function SLQueue() {
    var head = null;
    var tail = null;
}

function removeMinimums(q) {
    // find min value in entire queue
    var minVal = q.head.val;
    var runner = q.head.next;
    while (runner) {
        if (runner.val < minVal) {
            minVal = runner.val;
        }
        runner = runner.next;
    }

    // remove min values from front of queue
    runner = q.head;
    while (runner) {
        if (runner.val === minVal) {
            q.head = runner.next;
            runner = runner.next;
        } else {
            q.head = runner;
            break;
        }
    }

    // go through rest of queue and remove mins
    runner = q.head;
    while (runner.next) {
        if (runner.next.val === minVal) {
            runner.next = runner.next.next;
        }
        runner = runner.next;
    }
    
    // reset queue's tail
    runner = q.head;
    while (runner.next) {
        runner = runner.next;
    }
    q.tail = runner;
}