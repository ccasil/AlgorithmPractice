/*
Sort an array of integers by the number of 1s in their binary form. If two numbers have the same number of 1s, sort by their value.
*/

function int2Binary(int) {
  return int.toString(2);
}

function numberOfOnes(str) {
  var num = 0;
  for (var i = 0; i < str.length; i++) {
    if (str[i] === '1') {
      num++;
    }
  }
  return num;
}

function rearrange(elements) {
  elements.sort(function(a, b) {
    return a - b;
  });
  var bin = [];
  for (var i = 0; i < elements.length; i++) {
    var num = elements[i];
    var binNum = int2Binary(num);
    bin.push({
      val: num,
      numOfOnes: numberOfOnes(binNum)
    });
  }
  bin.sort(function(a, b) {
    var diff = a.numOfOnes - b.numOfOnes;
    if (diff !== 0) {
      return diff;
    }
    return a.val - b.val;
  });
  var sorted = [];
  for (var j = 0; j < bin.length; j++) {
    sorted.push(bin[j].val);
  }
  return sorted;
}

console.log(rearrange([5454,122,232,5,33]));