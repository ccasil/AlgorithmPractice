/* Create the remove method that finds a given key, removes the key/value pair, and returns the removed value (or null if the key was not found). */

function HashMap(cap) {
    this.cap = cap;
    this.hash = [];
}

HashMap.prototype.mod = function(input) {
    return (input % this.cap + this.cap) % this.cap;
}

HashMap.prototype.remove = function(key) {
    let code = key.hashCode();
    let index = this.mod(code);
    var toBeReturned = null;
    for (let i = 0; i < this.hash[index].length; i += 2) {
        if (this.hash[index][i] === key) {
            returned = this.hash[index][i+1];
            this.hash[index].splice(i, 2);
            break;
        }
    }
    return toBeReturned;
}