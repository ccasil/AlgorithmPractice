/* Create a find method to return the value for a given key. IF the key is not found, return null. */

function HashMap(cap) {
    this.cap = cap;
    this.hash = [];
}

HashMap.prototype.mod = function(input) {
    return (input % this.cap + this.cap) % this.cap;
}

HashMap.prototype.find = function(key) {
    let code = key.hashCode();
    let index = this.mod(code);
    for (let i = 0; i < this.hash[index].length; i += 2) {
        if (this.hash[index][i] === key) {
            return this.hash[index][i+1];
        }
    }
    return null;
}