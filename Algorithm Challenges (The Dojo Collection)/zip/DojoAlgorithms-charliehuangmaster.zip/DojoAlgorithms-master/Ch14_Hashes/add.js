/* Create the add method on HashMap to add a new key and value to the map. */

function HashMap(cap) {
    this.cap = cap;
    this.hash = [];
}

HashMap.prototype.mod = function(input) {
    return (input % this.cap + this.cap) % this.cap;
}

HashMap.prototype.insert = function(key, value) {
    let code = key.hashCode();
    let index = this.mod(code);
    if (this.hash[index] === undefined) {
        this.hash[index] = [key, value];
    } else {
        this.hash[index].push(key, value);
    }
    return this;
}