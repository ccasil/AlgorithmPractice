/* Write a method to rehash all keys after an increase in the capacity size if the size of the buckets grows too large. This also requires changing the Add method to include a check for the size of buckets when a new key/value pair is added. */

function HashMap(cap) {
    this.cap = cap;
    this.hash = [];
}

HashMap.prototype.mod = function(input) {
    return (input % this.cap + this.cap) % this.cap;
}

HashMap.prototype.insert = function(key, value) {
    let code = key.hashCode();
    let index = this.mod(code);
    if (this.hash[index] === undefined) {
        this.hash[index] = [key, value];
    } else {
        var exists = false;
        for (var i = 0; i < this.hash[index]; i += 2) {
            if (this.hash[index][i] === key) {
                this.hash[index][i][i+1] = value;
                exists = true;
                break;
            }
        }
        if (!exists) {
            this.hash[index].push(key, value);
        }
        if (i > 100) {
            this.cap *= 2;
            this.grow();
        }
    }
}

HashMap.prototype.grow = function() {
    var newHash = [];
    for (var i = 0; i < this.hash.length; i++) {
        if (this.hash[i] !== undefined) {
            for (var k = 0; k < this.hash[i].length; k += 2) {
                let newIndex = this.mod(this.hash[i][k].hashCode());
                if (newHash[newIndex] === undefined) {
                    newHash[newIndex] = [];
                }
                newHash[newIndex].push(this.hash[i][k], this.hash[i][k+1]);
            }
        }
    }
    this.hash = newHash;
}