/* Given a numerical array sorted from least to greatest, then rotated by an unknown amount, find and return the minimum value in the array. Use binary search. Assume the array contains no repeating values. */

function minSortedRotated(arr) {
    if (arr.length === 0) {
        return null;
    }
    if (arr.length === 1) {
        return arr[0];
    }
    var halfIndex = Math.floor(arr.length/2);
    var last1 = arr[halfIndex];
    var last2 = arr[arr.length - 1];
    if (last1 < last2) {
        return minSortedRotated(arr.slice(0, halfIndex+1));
    } else {
        return minSortedRotated(arr.slice(halfIndex));
    }
}

console.log(minSortedRotated([4,5,6,1,2,3]));
console.log(minSortedRotated([10,11,1,2,3,6,7,8,9]));