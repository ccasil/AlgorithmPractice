/* Use time-space tradeoff to accelerate average running time for iSigma(num) that returns sum of integers from 1 to num. */

var cache = [];

function smarterSum(num) {
    if (cache.length >= num) {
        return cache[num];
    } else {
        for (var i = cache.length; i <= num; i++) {
            cache[i] = cache[i-1] + i;
        }
    }
    return cache[num];
}