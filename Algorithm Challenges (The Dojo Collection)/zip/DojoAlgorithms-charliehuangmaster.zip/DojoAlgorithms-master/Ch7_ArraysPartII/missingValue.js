/* Given an array that contains consecutive integers in no particular order, with one integer value missing, return the missing value */

function missingValue(arr) {
    var min = arr[0];
    var max = arr[0];
    var dict = {};
    dict[arr[0]] = true;
    for (var i = 1; i < arr.length; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
        if (arr[i] > max) {
            max = arr[i];
        }
        dict[arr[i]] = true;
    }
    for (var i = min; i <= max; i++) {
        if (!dict[i]) {
            return i;
        }
    }
}

console.log(missingValue([2,-4,0,-3,-2,1]));
console.log(missingValue([5,2,7,8,4,9,3]));