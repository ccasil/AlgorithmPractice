/* Write a function that returns if the given array has a balance point between indices where one side's sum is equal to the other's. */

function balancePoint(arr) {
    if (arr.length < 2) {
        return false;
    }
    for (var i = 1; i < arr.length; i++) {
        var sum1 = 0;
        for (var j = 0; j < i; j++) {
            sum1 += arr[j];
        }
        var sum2 = 0;
        for (var j = i; j < arr.length; j++) {
            sum2 += arr[j];
        }
        if (sum1 === sum2) {
            return true;
        }
    }
    return false;
}

console.log(balancePoint([1,2,3,4,10]));
console.log(balancePoint([1,2,4,2,1]));