/* Remove array duplicates. Do not alter the original order. */

function removeDuplicates(arr) {
    var dict = {};
    for (var i = 0; i < arr.length; i++) {
        if (!dict[arr[i]]) {
            arr[Object.keys(dict).length] = arr[i];
            dict[arr[i]] = true;
        }
    }
    arr.length = Object.keys(dict).length;
    return arr;
}

console.log(removeDuplicates([1,1,1,2,2,3,4,6,6,6,7]));