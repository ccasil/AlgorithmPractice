function tacoTruck(arr) {
    if (arr.length < 1) {
        return null;
    }
    var maxX = arr[0][0];
    var minX = arr[0][0];
    var maxY = arr[0][1];
    var minY = arr[0][1];
    for (var i = 0; i < arr.length; i++) {
        if (arr[i][0] > maxX) {
            maxX = arr[i][0];
        } else if (arr[i][0] < minX) {
            minX = arr[i][0];
        }
        if (arr[i][1] > maxY) {
            maxY = arr[i][1];
        } else if (arr[i][1] < minY) {
            minY = arr[i][1];
        }
    }
    var distances = [];
    for (var x = minX; x <= maxX; x++) {
        for (var y = minY; y <= maxY; y++) {
            var distance = 0;
            for (var i = 0; i < arr.length; i++) {
                distance += Math.abs(x - arr[i][0]) + Math.abs(y - arr[i][1]);
            }
            distances.push([x, y, distance])
        }
    }
    var minDistance = distances[0][2];
    var minCoords = [distances[0][0], distances[0][1]];
    for (var i = 1; i < distances.length; i++) {
        if (distances[i][2] < minDistance) {
            minDistance = distances[i][2];
            minCoords = [distances[i][0], distances[i][1]];
        }
    }
    return minCoords;
}

console.log(tacoTruck([ [10,0], [-1,-10], [2,4] ]));
console.log(tacoTruck([ [10,0] ]));