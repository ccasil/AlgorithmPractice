/* Given an array, return the most frequent value(s) in the array */

function mode(arr) {
    var dict = {};
    for (var i = 0; i < arr.length; i++) {
        if (dict[arr[i]]) {
            dict[arr[i]]++;
        } else {
            dict[arr[i]] = 1;
        }
    }
    var max = 0;
    for (var val in dict) {
        if (dict[val] > max) {
            max = dict[val];
        }
    }
    var mode = [];
    for (var val in dict) {
        if (dict[val] === max) {
            mode.push(val);
        }
    }
    return mode;
}

console.log(mode([1,1,2,3,3,3,5,5,6,6,6,7]));
console.log(mode([1,1,2,3,3,3,5,5,6,6,6,6,7]));