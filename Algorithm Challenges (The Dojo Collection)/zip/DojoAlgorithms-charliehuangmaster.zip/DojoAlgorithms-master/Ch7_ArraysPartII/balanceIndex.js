/* Write a function that returns a given array's balance index where sums are equal on either side (excluding the index's own value). Return -1 if none exist. */

function balanceIndex(arr) {
    if (arr.length < 3) {
        return -1;
    }
    for (var i = 1; i < arr.length - 1; i++) {
        var sum1 = 0;
        for (var j = 0; j < i; j++) {
            sum1 += arr[j];
        }
        var sum2 = 0;
        for (var j = i + 1; j < arr.length; j++) {
            sum2 += arr[j];
        }
        if (sum1 === sum2) {
            return i;
        }
    }
    return -1;
}

console.log(balanceIndex([-2, 5, 7, 0, 3]));
console.log(balanceIndex([-2, 5, 7, 0, 4]));
console.log(balanceIndex([9, 9]));