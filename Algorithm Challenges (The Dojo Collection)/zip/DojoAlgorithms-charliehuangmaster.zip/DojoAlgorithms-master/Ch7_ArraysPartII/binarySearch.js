/* Given a sorted array and a value, return if the array contains that value. Do not sequentially iterate the array! Instead, use a binary search. */

function binarySearch(arr, val) {
    if (arr[arr.length - 1] < val) {
        return false;
    }
    if (arr.length === 0 || (arr.length === 1 && arr[0] !== val)) {
        return false;
    }
    var halfIndex = Math.floor(arr.length/2);
    if (arr[halfIndex] === val) {
        return true;
    } else if (arr[halfIndex] < val) {
        return binarySearch(arr.slice(halfIndex + 1), val);
    } else {
        return binarySearch(arr.slice(0, halfIndex), val);
    }
}

console.log(binarySearch([1,2,3,4,5,6,7,8,9], 8));
console.log(binarySearch([1,2,3,4,5,6,7,8,9], 10));
console.log(binarySearch([1,3,4,5,6,7,8,9], 2));