/* Given a numerical array taht is potentially very long, return the maximum sum of values from a subarray. Any consecutive sequence of indices in the array is considered a subarray. Return the highest sum possible from these subarrays. */

function maxOfSubarraySums(arr) {
    var maxSoFar = 0;
    var maxEndingHere = 0;
    for (var i = 0; i < arr.length; i++) {
        maxEndingHere += arr[i];
        if (maxEndingHere < 0) {
            maxEndingHere = 0;
        }
        if (maxEndingHere > maxSoFar) {
            maxSoFar = maxEndingHere;
        }
    }
    return maxSoFar;
}

console.log(maxOfSubarraySums([1,2,-4,3,-2,3,-1]));
console.log(maxOfSubarraySums([-1,-2,-3,-2,-1]));