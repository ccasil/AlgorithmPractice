/* use bubble sort to sort a singly linked list */

function bubbleSortSList(node) {
    var unordered = 1;
    while (unordered > 0) {
        unordered = 0;
        // if the first node in the list needs to get swapped
        if (node.val > node.next.val) {
            var temp = node;
            node = temp.next;
            temp.next = node.next;
            node.next = temp;
            unordered++;
            continue;
        // else, check if the following two nodes need to get swapped
        } else {
            var runner = node;
            while (runner.next.next) {
                if (runner.next.val > runner.next.next.val) {
                    var temp = runner.next;
                    runner.next = runner.next.next;
                    temp.next = runner.next.next;
                    runner.next.next = temp;
                    runner = runner.next;
                    unordered++;
                }
            }
        }
    }
    return node;
}