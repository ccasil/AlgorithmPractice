/* Use the partion array to implement a quick sort of an unsorted array in place. */

function quickSort(arr, start = 0, end = arr.length - 1) {
    if (!Array.isArray(arr)) {
        return;
    }
    if (end - start <= 1) {
        return arr;
    } else {
        var pivot = partition(arr, start, end);
        quickSort(arr, start, pivot);
        quickSort(arr, pivot + 1, end);
    }
    return arr;
}

function partition(arr, start, end) {
    var pivot = Math.floor(Math.random()*(end - start)) + start;
    var i = start-1;
    var j = start;
    while (j <= end) {
        if (arr[pivot] > arr[j]) {
            i++;
            if (i !== j) {
                var temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            if (i === pivot) {
                pivot = j;
            }
            j++;
        } else {
            j++;
        }
    }
    i++;
    var temp = arr[i];
    arr[i] = arr[pivot];
    arr[pivot] = temp;
    pivot = i;
    return pivot;
}

console.log(quickSort([5,4,9,2,5,3,18,23,10,6,33,2,1,12]));
console.log(quickSort([5,4,9,2,5,3,18,23,10,6,33,2,1,12], 3));
console.log(quickSort([5,4,9,2,5,3,18,23,10,6,33,2,1,12], 3, 8));
console.log(quickSort([1]));
console.log(quickSort([]));
console.log(quickSort(2));