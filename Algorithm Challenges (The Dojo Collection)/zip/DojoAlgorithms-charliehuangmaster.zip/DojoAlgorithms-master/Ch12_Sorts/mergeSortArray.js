function mergeSort(arr) {
    if (arr.length === 1) {
        return arr;
    } else {
        var half = Math.floor(arr.length/2);
        var arr1 = arr.slice(0, half);
        var arr2 = arr.slice(half);
        return combineArrays(mergeSort(arr1), mergeSort(arr2));
    }
}

function combineArrays(arr1, arr2) {
    let arr2Start = arr1.length;
    arr1 = arr1.concat(arr2);
    insertionSort(arr1, arr2Start);
    return arr1;
    
    function insertionSort(arr, start) {
        for (let i = start; i < arr.length; i++) {
            let current = arr[i];
            let j = i - 1;
            while (j >= 0 && arr[j] > current) {
                arr[j+1] = arr[j];
                j--;
            }
            arr[j+1] = current;
        }
        return arr;
    }
}

console.log(mergeSort([4,1,6,2,4,7,3,4]));