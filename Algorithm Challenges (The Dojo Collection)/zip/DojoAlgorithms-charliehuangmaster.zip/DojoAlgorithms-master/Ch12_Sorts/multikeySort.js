/* Given an array of objects, where each object contains a firstName and a lstName key, sort the array by both last name (primary) and first name (secondary). */

function multikeySort(arr) {
    var unordered = true;
    while (unordered) {
        unordered = false;
        for (var i = 0; i < arr.length - 1; i++) {
            for (var j = 0; j < arr[i].lastName.length; j++) {
                var charLast1 = arr[i].lastName[j].toLowerCase().charCodeAt(0);
                var charLast2 = arr[i+1].lastName[j].toLowerCase().charCodeAt(0);
                if (charLast1 > charLast2) {
                    var temp = arr[i];
                    arr[i] = arr[i+1];
                    arr[i+1] = temp;
                    unordered = true;
                    break;
                } else if (charLast1 < charLast2) {
                    break;
                }
            }
            if (!unordered && arr[i].lastName === arr[i+1].lastName) {
                for (var k = 0; k < arr[i].firstName.length; k++) {
                    var charFirst1 = arr[i].firstName[k].toLowerCase().charCodeAt(0);
                    var charFirst2 = arr[i+1].firstName[k].toLowerCase().charCodeAt(0);
                    if (charFirst1 > charFirst2) {
                        var temp = arr[i];
                        arr[i] = arr[i+1];
                        arr[i+1] = temp;
                        unordered = true;
                        break;
                    } else if (charFirst1 < charFirst2) {
                        break;
                    }
                }
            }
        }
    }
    return arr;
}

console.log(multikeySort([
    {firstName: 'Giorgio', lastName: 'Carnevale'},
    {firstName: 'Aaron', lastName: 'Carnevale'},
    {firstName: 'Daniel', lastName: 'Ainsley'},
]));