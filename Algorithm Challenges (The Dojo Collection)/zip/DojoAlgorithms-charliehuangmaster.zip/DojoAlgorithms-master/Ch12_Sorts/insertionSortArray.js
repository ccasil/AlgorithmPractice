/* Use insertion sort to sort an unsorted array in place */

// function insertionSort(arr) {
//     for (let i = 1; i < arr.length; i++) {
//         for (let j = i - 1; j >= 0; j--) {
//             if (arr[j] < arr[i]) {
//                 shiftRight(arr, j + 1, i);
//                 break;
//             } else if (j === 0) {
//                 shiftRight(arr, j, i);
//                 break;
//             }
//         }
//     }
//     return arr;
    
//     function shiftRight(arr, start, end) {
//         if (start === end) {
//             return;
//         }
//         let temp = arr[end];
//         for (let i = end; i > start; i--) {
//             arr[i] = arr[i-1];
//         }
//         arr[start] = temp;
//     }
// }

// A more efficient way:
function insertionSort(arr) {
    for (let i = 1; i < arr.length; i++) {
        let current = arr[i];
        let j = i - 1;
        while (j >= 0 && arr[j] > current) {
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = current;
    }
    return arr;
}

console.log(insertionSort([5, 1, 4, 2, 8]));
console.log(insertionSort([45, 32, 4, 28, 45, 48, 31]));