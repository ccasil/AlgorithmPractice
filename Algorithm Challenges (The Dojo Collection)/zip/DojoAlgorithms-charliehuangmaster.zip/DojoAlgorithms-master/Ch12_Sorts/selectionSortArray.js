/* Use selection sort to sort an unsorted array in place */

function selectionSortArray(arr) {
    for (var i = 0; i < arr.length - 1; i++) {
        var minIndex = findMinIndex(arr, i);
        var temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
    return arr;

    function findMinIndex(arr, start) {
        var min = arr[start];
        var minIndex = start;
        for (var i = start + 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
                minIndex = i;
            }
        }
        return minIndex;
    }
}


console.log(selectionSortArray([5, 1, 4, 2, 8]));
console.log(selectionSortArray([4, 45, 32, 28, 45, 48, 31]));