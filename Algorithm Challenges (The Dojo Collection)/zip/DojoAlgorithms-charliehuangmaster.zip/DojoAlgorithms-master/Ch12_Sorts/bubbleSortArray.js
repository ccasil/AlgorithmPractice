/* Use bubble sort to sort an unsorted array in-place. */

function bubbleSortArray(arr) {
    var count = 0;
    var unordered = true;
    while (unordered) {
        unordered = false;
        for (var i = 0; i < arr.length - 1 - count; i++) {
            if (arr[i] > arr[i+1]) {
                var temp = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = temp;
                unordered = true;;
            }
        }
        count++;
    }
    return arr;
}

console.log(bubbleSortArray([5, 1, 4, 2, 8]));
console.log(bubbleSortArray([4, 45, 32, 28, 45, 48, 31]));