/* Given two sorted arrays, place the second array into the first array and sort in place */

// function combine(arr1, arr2) {
//     let arr2Start = arr1.length;
//     arr1 = arr1.concat(arr2);
//     insertionSort(arr1, arr2Start);
//     return arr1;
    
//     function insertionSort(arr, start) {
//         for (let i = start; i < arr.length; i++) {
//             let current = arr[i];
//             let j = i - 1;
//             while (j >= 0 && arr[j] > current) {
//                 arr[j+1] = arr[j];
//                 j--;
//             }
//             arr[j+1] = current;
//         }
//         return arr;
//     }
// }

// function combine(arr1, arr2) {
//     var merged = [];
//     var arr1copy = arr1.slice(0);
//     var arr2copy = arr2.slice(0);
//     while (arr1copy.length > 0 && arr2copy.length > 0) {
//         if (arr1copy[0] < arr2copy[0]) {
//             merged.push(arr1copy.shift());
//         } else {
//             merged.push(arr2copy.shift());
//         }
//     }
//     while (arr1copy.length > 0) {
//         merged.push(arr1copy.shift());
//     }
//     while (arr2copy.length > 0) {
//         merged.push(arr2copy.shift());
//     }
//     return merged;
// }

function combine(arr1, arr2) {
    for (let i = 0; i < arr2.length; i++) {
        for (var j = 0; j < arr1.length; j++) {
            if (arr1[j] > arr2[i]) {
                break;
            }
        }
        for (var k = arr1.length - 1; k >= j; k--) {
            arr1[k + 1] = arr1[k];
        }
        arr1[j] = arr2[i];
    }
    return arr1;
}

console.log(combine([1,5,6,9], [2,7,8]));
console.log(combine([2,5,6,9], [1,7,8]));