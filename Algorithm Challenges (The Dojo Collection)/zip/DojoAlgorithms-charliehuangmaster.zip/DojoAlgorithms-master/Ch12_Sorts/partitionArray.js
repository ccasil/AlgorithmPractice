/* Partition an unsorted array in place. Use arr[0] as the pivot value and return the index of the pivot after partitioning.

e.g., Input [5,4,9,2,5,3] should become [4,2,3,5,9,5] and return 3. */

function partition(arr, pivot) {
    var i = -1;
    var j = 0;
    while (j < arr.length) {
        if (arr[pivot] > arr[j]) {
            i++;
            if (i !== j) {
                var temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            if (i === pivot) {
                pivot = j;
            }
            j++;
        } else {
            j++;
        }
    }
    i++;
    var temp = arr[i];
    arr[i] = arr[pivot];
    arr[pivot] = temp;
    pivot = i;
    console.log(arr);
    return pivot;
}

console.log(partition([5,4,9,2,5,3], 2));