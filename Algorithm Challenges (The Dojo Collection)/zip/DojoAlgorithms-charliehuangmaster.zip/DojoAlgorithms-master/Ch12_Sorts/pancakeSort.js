/* Given an arbitrarily large stack of N pancakes, how many spatula slips will it take to sort the pancakes into width order? */

function pancakeSort(arr) {
    var flips = 0;
    var pancakesSorted = 0;
    while (pancakesSorted < arr.length - 1) {
        var flipIndex = findMaxIndex(arr, arr.length - pancakesSorted);
        flip(arr, flipIndex);
        flips++;
        flip(arr, arr.length - 1 - pancakesSorted);
        flips++;
        pancakesSorted++;
    }
    console.log(arr);
    return flips;
}

console.log(pancakeSort([2,5,3,4,7,1]));

function findMaxIndex(arr, end) {
    var max = arr[0];
    var maxIndex = 0;
    for (var i = 1; i < end; i++) {
        if (arr[i] > max) {
            max = arr[i];
            maxIndex = i;
        }
    }
    return maxIndex;
}

function flip(arr, insert) {
    for (var i = 0; i < insert/2; i++) {
        var temp = arr[i];
        arr[i] = arr[insert - i];
        arr[insert - i] = temp;
    }
    return arr;
}