/* Create a function that, given a string, returns the integer made from the string's digits. */

function getDigits(str) {
    var output = '';
    var chars = str.split('');
    chars.forEach(function(char) {
        if (isNaN(parseInt(char)) === false) {
            output += char;
        }
    });
    return parseInt(output);
}

console.log(getDigits('0s1a3y5w7h9a2t4?6!8?0'));