/* Given a positive integer that is less than 4000, return a string containing that value in Roman numeral representation. I is 1, V is 5, X is 10, L is 50, C is 100, D is 500, and M is 1000 */

function intToRomanNumerals(int) {
    var romanNumerals = [
        [1000, 'M'],
        [900, 'CM'],
        [500, 'D'],
        [490, 'XD'],
        [400, 'CD'],
        [100, 'C'],
        [90, 'XC'],
        [50, 'L'],
        [49, 'IL'],
        [40, 'XL'],
        [10, 'X'],
        [9, 'IX'],
        [5, 'V'],
        [4, 'IV'],
        [1, 'I']
    ];
    
    var output = '';
    while (int > 0) {
        for (var i = 0; i < romanNumerals.length; i++) {
            if (int - romanNumerals[i][0] >= 0) {
                output += romanNumerals[i][1];
                int -= romanNumerals[i][0];
                break;
            }
        }
    }
    return output;
}

console.log(intToRomanNumerals(349));