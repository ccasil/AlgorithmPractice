/* Given a string, return the longest palindromic substring. Include spaces, tabs, returns, capitalization, and punctuation. */

function longestPalindrome(str) {
    var longestPal = str[0];
    for (var i = 0; i < str.length; i++) {
        var subStr = '';
        for (var j = i; j < str.length; j++) {
            subStr += str[j];
            if (isPalindrome(subStr) && subStr.length > longestPal.length) {
                longestPal = subStr;
            }
        }
    }
    return longestPal;
}

function longestPalindrome2(str) {
    str = str.toUpperCase();
    var longestPal = str[0];
    for (var i = 0; i < str.length; i++) {
        var subStr = '';
        for (var j = i; j < str.length; j++) {
            var code = str.charCodeAt(j);
            if (code > 64 && code < 91) {
                subStr += str[j];
                if (isPalindrome(subStr) && subStr.length > longestPal.length) {
                    longestPal = subStr;
                }
            }
        }
    }
    return longestPal;
}

function isPalindrome(str) {
    var strChars = str.split('');
    var reverseStrArr = [];
    for (var i = strChars.length - 1; i >= 0; i--) {
        reverseStrArr.push(strChars[i]);
    }
    return str === reverseStrArr.join('');
}

console.log(longestPalindrome('what up, daddy-o?'));
console.log(longestPalindrome('uh... not much'));
console.log(longestPalindrome('Yikes! my favorite racecar erupted!'));
console.log(longestPalindrome2('Hot puree eruption!'));