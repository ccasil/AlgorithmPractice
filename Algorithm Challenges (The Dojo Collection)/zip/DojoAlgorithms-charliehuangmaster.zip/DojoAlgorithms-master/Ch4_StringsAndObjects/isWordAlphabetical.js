/* Given a string, return if all contained letters are in alphabetical order */

function isWordAlphabetical(str) {
    for (var i = 1; i < str.length; i++) {
        if (str[i] < str[i-1]) {
            return false;
        }
    }
    return true;
}

console.log(isWordAlphabetical('abef'));
console.log(isWordAlphabetical('abfe'));