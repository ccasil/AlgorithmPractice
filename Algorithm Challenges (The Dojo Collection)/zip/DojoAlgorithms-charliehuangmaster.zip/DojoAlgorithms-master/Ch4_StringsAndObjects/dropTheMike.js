/* Given an input string, remove the leading and trailing white space, capitalize the first letter of every word, and return that string. If the original string contains the word 'Mike' anywhere, immediately return 'stunned silence' instead. */

function dropTheMike(str) {
    for (var i = 0; i < str.length - 3; i++) {
        var subStr = str[i] + str[i+1] + str[i+2] + str[i+3];
        if (subStr === 'Mike') {
            return 'stunned silence';
        }
    }
    str = str.split(' ');
    var newStrArr = [];
    for (var i = 0; i < str.length; i++) {
        if (str[i] !== '') {
            var wordArr = str[i].split('');
            wordArr[0] = wordArr[0].toUpperCase();
            newStrArr.push(wordArr.join(''));
        }
    }
    str = newStrArr.join(' ');
    return str;
}

console.log(dropTheMike('     hello there what\'s up    '));
console.log(dropTheMike('     hello there Mike what\'s up    '));