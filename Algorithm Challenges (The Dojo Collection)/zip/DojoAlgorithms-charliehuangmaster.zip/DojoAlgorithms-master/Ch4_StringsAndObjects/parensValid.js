/* Create a function that, given an input string, returns a boolean for if parentheses in the string are valid. Valid sets of parentheses always open before they close. */

function parensValid(str) {
    var chars = str.split('');
    var counter = 0;
    for (var i = 0; i < chars.length; i++) {
        if (chars[i] === '(') {
            counter++;
        } else if (chars[i] === ')') {
            counter--;
        }
        if (counter < 0) {
            return false;
        }
    }
    if (counter === 0) {
        return true;
    } else {
        return false;
    }
}

console.log(parensValid('N(0(p)3'));
console.log(parensValid('Y(3(p)p(3)r)s'));