/* Accept a string and return the number of non-space characters found in the string*/

function nonSpace(str) {
    var words = str.split(' ');
    var newStr = words.join('');
    return newStr.length;
}

var str = 'honey pie, you are driving me crazy';
console.log(nonSpace(str));