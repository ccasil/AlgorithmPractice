/* Given a word array, return the largest suffix (word-end) common to all words in the array */

function commonSuffix(arr) {
    var word0 = arr[0];
    var suffix = '';
    for (var i = word0.length - 1; i >= 0; i--) {
        var tempsuffix = word0[i] + suffix;
        for (var j = 1; j < arr.length; j++) {
            var suffix_j = '';
            for (var k = arr[j].length - suffix.length - 1; k < arr[j].length; k++) {
                suffix_j += arr[j][k];
            }
            if (tempsuffix !== suffix_j) {
                return suffix;
            }
        }
        suffix = tempsuffix;
    }
    return suffix;
}

console.log(commonSuffix(['citation','conviction','incarceration']));
console.log(commonSuffix(['nice','ice','baby']));
console.log(commonSuffix(['sabcd','eabcd','labcd']));