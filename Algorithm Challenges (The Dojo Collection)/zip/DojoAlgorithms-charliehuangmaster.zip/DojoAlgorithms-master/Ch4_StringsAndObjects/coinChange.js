/* Given a number of US cents, return the optimal configuration of coins in an object */

function coinChange(cents) {
    var denoms = [['quarters', 25], ['dimes', 10], ['nickels', 5], ['pennies', 1]];
    var change = {};
    denoms.forEach(function(denom) {
        var count = Math.floor(cents/denom[1]);
        change[denom[0]] = count;
        cents = cents%denom[1];
    });
    return change;
}

console.log(coinChange(69));