/* Given a sorted array of pages where a term appears, produce an index string. Consecutive pages should form ranges separated by a hyphen. */

function bookIndex(arr) {
    var outputArr = [arr[0]];
    for (var i = 1; i < arr.length; i++) {
        if (arr[i] !== arr[i-1] + 1) {
            outputArr.push((arr[i]).toString());
            continue;
        }
        if (arr[i] !== arr[i+1] - 1) {
            outputArr[outputArr.length - 1] += '-' + arr[i].toString();
        }
    }
    return outputArr.join(', ');
}

console.log(bookIndex([1, 13, 14, 15, 37, 38, 70]));
console.log(bookIndex([1, 13, 15, 37, 38, 70]));