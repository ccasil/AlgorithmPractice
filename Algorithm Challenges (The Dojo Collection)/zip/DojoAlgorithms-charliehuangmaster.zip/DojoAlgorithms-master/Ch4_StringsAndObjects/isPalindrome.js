/* Create a function that returns a boolean for if the string is a strict palindrome. (Do not ignore spaces, punctuation, and capitlization) */

function isPalindrome(str) {
    var strChars = str.split('');
    var reverseStrArr = [];
    for (var i = strChars.length - 1; i >= 0; i--) {
        reverseStrArr.push(strChars[i]);
    }
    return str === reverseStrArr.join('');
}

console.log(isPalindrome('a x a'));
console.log(isPalindrome('Dud'));

/* Now do ignore white space (spaces, tabs, returns), capitalization, and punctuation. */

function isPalindrome2(str) {
    str = str.toUpperCase();
    var strAlpha = [];
    for (var i = 0; i < str.length; i++) {
        var code = str.charCodeAt(i);
        if (code > 64 && code < 91) {
            strAlpha.push(str[i]);
        }
    }
    var reverseStrAlpha = [];
    for (var i = strAlpha.length - 1; i >= 0; i--) {
        reverseStrAlpha.push(strAlpha[i]);
    }
    return strAlpha.join('') === reverseStrAlpha.join('');
}

console.log(isPalindrome2("Madam, I'm Adam"));
console.log(isPalindrome2("Able was     I , ere I saw Elb   a"));
console.log(isPalindrome2("Madam, I'm Aam"));