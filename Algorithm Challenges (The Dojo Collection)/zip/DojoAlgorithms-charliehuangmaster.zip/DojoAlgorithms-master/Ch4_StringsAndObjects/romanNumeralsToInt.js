/* Given a string containing a Roman numeral representation of a positive integer, return the integer. */

function romanNumeralsToInt(rn) {
    var romanNumerals = [
        [1000, 'M'],
        [900, 'CM'],
        [500, 'D'],
        [490, 'XD'],
        [400, 'CD'],
        [100, 'C'],
        [90, 'XC'],
        [50, 'L'],
        [49, 'IL'],
        [40, 'XL'],
        [10, 'X'],
        [9, 'IX'],
        [5, 'V'],
        [4, 'IV'],
        [1, 'I']
    ];

    function checkRN(input, RNs, rnChars, shifts) {
        for (var i = 0; i < RNs.length; i++) {
            if (input === RNs[i][1]) {
                output += RNs[i][0];
                for (var j = 0; j < shifts; j++) {
                    rnChars.shift();
                }
            break;
            }
        }
    }

    var output = 0;
    var rnChars = rn.split('');
    while (rnChars.length > 1) {
        var next2chars = rnChars[0] + rnChars[1];
        checkRN(next2chars, romanNumerals, rnChars, 2);
        checkRN(rnChars[0], romanNumerals, rnChars, 1);
    }
    if (rnChars.length === 1) {
        checkRN(rnChars[0], romanNumerals, rnChars, 1);
    }
    return output;
}

console.log(romanNumeralsToInt('DCIX'));