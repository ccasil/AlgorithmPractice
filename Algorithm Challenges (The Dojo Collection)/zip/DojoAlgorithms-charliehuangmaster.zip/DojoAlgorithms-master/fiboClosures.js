function Fibo() {
  var num1 = 0;
  var num2 = 1;
  return function() {
    var prevNum1 = num1;
    num1 = num2;
    num2 += prevNum1;
    console.log(prevNum1);
  }
}

var fib = new Fibo();
fib();
fib();
fib();
fib();
fib();
fib();
fib();
fib();