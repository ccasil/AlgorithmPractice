function minHeap() {
    this.heap = [undefined];
}

// 1. push new val into heap
// 2. find the parent of the newly added value
// 3. if newly added value is smaller than parent, swap them
// 4. redefine current value, find its parent, and repeat step 3 until current is equal or greater to parent, or current's index is smaller than 1

minHeap.prototype.insert = function(val) {
    this.heap.push(val);
    var current = this.heap.length - 1;
    var parent = Math.floor(current/2);
    while(this.heap[current] < this.heap[parent] && current > 0) {
        var temp = this.heap[parent];
        this.heap[parent] = this.heap[current];
        this.heap[current] = temp;
        current = parent;
        parent = Math.floor(current/2);
    }
}

var h = new minHeap();
h.insert(4);
h.insert(2);
h.insert(9);
h.insert(7);
h.insert(1);
h.insert(3);
console.log(h.heap);