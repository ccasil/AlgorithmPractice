function minHeap() {
    this.heap = [undefined];
}

// 1. move value at index 0 to end, and add undefined to index 0
// 2. find the last parent
// 3. check if any children are smaller than it, and if so, swap
// 4. go the next parent up, and repeat step 3 until parent index is smaller than 1

minHeap.prototype.heapify = function(arr) {
    arr[arr.length] = arr[0];
    arr[0] = undefined;
    var target = Math.floor((arr.length-1)/2);
    var current = target;
    while (target > 0) {
        var child1 = current*2;
        var child2 = child1+1;
        var minChild = (arr[child1] < arr[child2]) ? child1 : child2;
        if (arr[child2] === undefined) {
            minChild = child1;
        }
        if (arr[minChild] !== undefined && arr[minChild] < arr[current]) {
            var temp = arr[current];
            arr[current] = arr[minChild];
            arr[minChild] = temp;
            current = minChild;
            continue;
        }
        target--;
        current = target;
    }
    this.heap = arr;
}

var h = new minHeap();
h.heapify([3,23,18,2,15,3,1,20,0,19]);
console.log(h.heap);