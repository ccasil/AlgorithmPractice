function minHeap() {
    this.heap = [undefined];
}

// 1. swap element at index 1 (the top element to be removed) with last element
// 2. pop off last element (save it to be returned later)
// 3. set parent at index 1
// 4. check if either of parent's children are less than it, and if so, swap with the smaller child
// 5. redefine parent as the child that got swapped, then repeat step 4 until either both its children are greater than it or it has no children

minHeap.prototype.extract = function() {
    var temp = this.heap[1];
    this.heap[1] = this.heap[this.heap.length - 1];
    this.heap[this.heap.length - 1] = temp;
    var toBeReturned = this.heap.pop();
    var parent = 1;
    var child1 = parent*2;
    var child2 = child1+1;
    while (child1 < this.heap.length) {
        var minChild = (this.heap[child1] < this.heap[child2]) ? child1 : child2;
        if (this.heap[minChild] === undefined) {
            minChild = child1;
        }
        if (this.heap[minChild] < this.heap[parent]) {
            var temp = this.heap[parent];
            this.heap[parent] = this.heap[minChild];
            this.heap[minChild] = temp;
            parent = minChild;
            child1 = parent*2;
            child2 = child1+1;
            continue;
        }
        break;
    }
    return toBeReturned;
}

var h = new minHeap();
h.heap = [undefined, 1, 2, 3, 7, 4, 9];
console.log(h.extract());
console.log(h.heap);