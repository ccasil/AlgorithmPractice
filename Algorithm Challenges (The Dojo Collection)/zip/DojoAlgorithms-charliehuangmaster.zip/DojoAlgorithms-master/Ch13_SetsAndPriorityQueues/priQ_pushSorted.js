function PriQueue() {
    this.head = null;
}

function PriQNode(value, priority) {
    this.val = value;
    this.pri = priority;
    this.next = null;
}

PriQueue.prototype.pushSorted = function(value, priority) {
    var newNode = new PriQNode(value, priority);
    if (!this.head) {
        this.head = newNode;
    } else {
        if (this.head.pri > newNode.pri) {
            newNode.next = this.head;
            this.head = newNode;
        } else {
            var runner = this.head;
            if (!runner.next) {
                this.head.next = newNode;
            } else {
                while (runner.next) {
                    if (runner.next.pri > newNode.pri) {
                        newNode.next = runner.next;
                        runner.next = newNode;
                        return;
                    }
                    runner = runner.next;
                }
                runner.next = newNode;
            }
        }
    }
}