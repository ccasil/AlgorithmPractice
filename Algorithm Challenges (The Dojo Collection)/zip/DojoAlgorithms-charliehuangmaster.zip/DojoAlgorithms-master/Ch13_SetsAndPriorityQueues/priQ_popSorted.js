function PriQueue() {
    this.head = null;
}

function PriQNode(value, priority) {
    this.val = value;
    this.pri = priority;
    this.next = null;
}

PriQueue.prototype.popSorted = function() {
    if (!this.head) {
        return;
    } else {
        var temp = this.head;
        this.head = this.head.next;
        return temp;
    }
}