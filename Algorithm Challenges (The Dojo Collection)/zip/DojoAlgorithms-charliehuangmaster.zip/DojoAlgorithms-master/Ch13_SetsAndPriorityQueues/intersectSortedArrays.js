/* Combine two sorted arrays into an array containing the sorted multiset intersection of the two. */

function intersection(arr1, arr2) {
    var intersection = [];
    var i = 0;
    var k = 0;
    while (i < arr1.length || k < arr2.length) {
        if (arr1[i] === arr2[k]) {
            intersection.push(arr1[i]);
            i++;
            k++;
        } else if (arr1[i] > arr2[k]) {
            k++;
        } else {
            i++;
        }
    }
    return intersection;
}

console.log(intersection([1,2,3,3,4,4,4,5], [2,3,4,4]));
console.log(intersection([1,2,2,2,7], [2,2,6,6,7]));