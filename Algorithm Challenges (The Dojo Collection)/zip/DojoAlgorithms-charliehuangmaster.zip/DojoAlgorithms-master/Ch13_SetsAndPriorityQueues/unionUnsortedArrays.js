/* Return a new unsorted union multiset of two arrays; do not alter the originals */

function union(arr1, arr2) {
    var union = [];
    var dict = {};
    for (var i = 0; i < arr1.length; i++) {
        if (dict[arr1[i]]) {
            dict[arr1[i]]++;
        } else {
            dict[arr1[i]] = 1;
        }
        union.push(arr1[i]);
    }
    for (var i = 0; i < arr2.length; i++) {
        if (dict[arr2[i]] > 0) {
            dict[arr2[i]]--;
        } else {
            union.push(arr2[i]);
        }
    }
    return union;
}

console.log(union([6,7,2,7,6,2], [2,7,2,1,2]));