function PriQueue() {
    this.head = null;
}

function PriQNode(value, priority) {
    this.val = value;
    this.pri = priority;
    this.next = null;
}

PriQueue.prototype.popUnsorted = function(value, priority) {
    var newNode = new PriQNode(value, priority);
    if (!this.head) {
        return;
    }
    var min = this.head.pri;
    var runner = this.head.next;
    while (runner) {
        if (runner.pri < min) {
            min = runner.pri;
        }
        runner = runner.next;
    }
    if (this.head.pri === min) {
        var temp = this.head;
        this.head = this.head.next;
        return temp;
    } else {
        var runner = this.head;
        while (runner.next) {
            if (runner.next.pri === min) {
                var temp = runner.next;
                runner.next = runner.next.next;
                return temp;
            }
        }
    }
}