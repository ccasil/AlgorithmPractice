/* Return the index of the first unique (case-sensitive) character in a given string. Given "empathetic monarch meets primo stinker", return 35. */

function indexOfFirstUniqueLetter(str) {
    var dict = {};
    for (var i = 0; i < str.length; i++) {
        if (str[i] !== " ") {
            if (!dict[str[i]]) {
                dict[str[i]] = 1;
            } else {
                dict[str[i]]++;
            }
        }
    }

    for (var i = 0; i < str.length; i++) {
        if (dict[str[i]] === 1) {
            return i;
        }
    }
}

console.log(indexOfFirstUniqueLetter("empathetic monarch meets primo stinker"));