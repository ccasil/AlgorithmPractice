/* Given a string of words (with spaces), return a new string with the words in reverse order */

function reverseWordOrder(str) {
    var output = "";
    var word = "";
    for (var i = 0; i < str.length; i++) {
        if (str[i] !== " ") {
            word += str[i];
        } else {
            output = word + " " + output;
            word = "";
        }
    }
    output = word + " " + output;
    output.length--;
    return output;
}

console.log(reverseWordOrder("This is a test"));