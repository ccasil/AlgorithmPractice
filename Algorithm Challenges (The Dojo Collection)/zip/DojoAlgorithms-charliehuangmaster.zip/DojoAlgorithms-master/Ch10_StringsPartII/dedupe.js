/* Remove duplicate characters (case-sensitive) including punctuation. Keep only the LAST instance of each character. Given "Snaps! crackles! pops!", return "Snrackel ops!" */

function dedupe(str) {
    var output = "";
    var dict = {};
    for (var i = str.length-1; i >= 0; i--) {
        if (!dict[str[i]]) {
            output = str[i] + output;
            dict[str[i]] = true;
        }
    }
    return output;
}

console.log(dedupe("Snaps! crackles! pops!"));