/* Given an encoded string (see Encode algorithm), decode and return it.

e.g. Given "a4b2c1d3", return "aaaabbcddd". */

function decode(str) {
    var output = "";
    for (var i = 0; i < str.length - 1; i += 2) {
        for (var j = 0; j < parseInt(str[i+1]); j++) {
            output += str[i];
        }
    }
    return output;
}

console.log(decode("a4b2c1d3"));