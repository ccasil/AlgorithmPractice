/* Return only the unique characters from a given string.  Specifically, omit all instances of a (case-sensitive) character if it appears more than once, respecting spaces and punctuation. Given "Snap! Crackle! Poop!", return "SnCrckleP". */

function uniqueLetters(str) {
    var output = "";
    var dict = {};
    for (var i = 0; i < str.length; i++) {
        if (!dict[str[i]]) {
            dict[str[i]] = 1;
        } else {
            dict[str[i]]++;
        }
    }
    for (var i = 0; i < str.length; i++) {
        if (dict[str[i]] === 1) {
            output += str[i];
        }
    }
    return output;
}

console.log(uniqueLetters("Snap! Crackle! Poop!"));