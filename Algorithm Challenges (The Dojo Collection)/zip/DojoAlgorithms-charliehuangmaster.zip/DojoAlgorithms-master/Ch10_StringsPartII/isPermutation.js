/* Create a function that returns if one string is a permutation of another. Given ["mister", "stimer"], return true. Given ["mister", "sister"], return false. */

function isPermutation(str1, str2) {
    if (str1.length !== str2.length) {
        return false;
    }

    var dict = {};
    for (var i = 0; i < str1.length; i++) {
        var letter = str1[i].toLowerCase();
        if (!dict[letter]) {
            dict[letter] = 1;
        } else {
            dict[letter]++;
        }
    }
    
    for (var i = 0; i < str2.length; i++) {
        var letter = str2[i].toLowerCase();
        if (dict[letter]) {
            dict[letter]--;
        }
    }

    for (var letter in dict) {
        if (dict[letter] !== 0) {
            return false;
        }
    }
    return true;
}

console.log(isPermutation("mister", "stimer"));
console.log(isPermutation("mister", "sister"));