/* Given a string, retain the words that occur only once.

e.g. Given "Sing! Sing a song; sing out loud; sing out strong", return "Sing! Sing a song; loud; strong". */

function uniqueWords(str) {
    var wordArr = [];
    var word = "";
    for (var i = 0; i < str.length; i++) {
        if (str[i] !== " ") {
            word += str[i];
        } else {
            wordArr.push(word);
            word = "";
        }
    }
    wordArr.push(word);

    var dict = {};
    for (var i = 0; i < wordArr.length; i++) {
        if (!dict[wordArr[i]]) {
            dict[wordArr[i]] = 1;
        } else {
            dict[wordArr[i]]++;
        }
    }

    var output = "";
    for (var i = 0; i < wordArr.length; i++) {
        if (dict[wordArr[i]] === 1) {
            output += wordArr[i] + " ";
        }
    }

    output.length--;
    return output;
}

console.log(uniqueWords("Sing! Sing a song; sing out loud; sing out strong."));