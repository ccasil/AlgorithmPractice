/* Given an array of bad words and a string, replace all the bad words in the string with Xs */

function censor(str, arr) {
    for (var i = 0; i < arr.length; i++) {
        var repl = "";
        for (var n = 0; n < arr[i].length; n++) {
            repl += "X";
        }
        for (var j = 0; j < str.length; j++) {
            var subStr = str.slice(j, j + repl.length);
            if (subStr === arr[i]) {
                str = str.slice(0, j) + repl + str.slice(j + repl.length);
            }
        }
    }
    return str;
}

console.log(censor("crackle poops", ["crack", "poop"]));
console.log(censor("snap crackle pop nincompoop", ["crack", "poop"]));