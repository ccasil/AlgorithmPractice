/* Given a string of words, return the longest word in the string */

function longestWord(str) {
    var wordArr = [];
    var word = "";
    for (var i = 0; i < str.length; i++) {
        if (str[i] !== " ") {
            word += str[i];
        } else {
            wordArr.push(word);
            word = "";
        }
    }
    wordArr.push(word);
    
    var longestWord = wordArr[0];
    for (var i = 1; i < wordArr.length; i++) {
        if (wordArr[i].length > longestWord.length) {
            longestWord = wordArr[i];
        }
    }
    return longestWord;
}

console.log(longestWord("snap crackle pop makes the world go round"));