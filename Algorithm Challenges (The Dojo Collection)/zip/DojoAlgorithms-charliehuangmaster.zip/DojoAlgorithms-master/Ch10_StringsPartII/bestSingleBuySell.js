/* Given an array of stock prices, write a function that returns the maximal profit from one purchase followed by one sale.

e.g. bestSingleBuySell([6,4,6,5,9,7,6,12,2,6,11,2,4]) returns a maximal profit of 9. */

// function bestSingleBuySell(arr) {
//     if (arr.length < 2) {
//         return false;
//     } else {
//         var profits = [];
//         getProfits(arr, profits);
//         return Math.max.apply(null, profits);
//     }

//     function getProfits(arr, profits) {
//         if (arr.length === 2) {
//             profits.push(arr[1] - arr[0]);
//         } else {
//             getProfits(arr.slice(1), profits);
//             for (var i = 1; i < arr.length; i++) {
//                 profits.push(arr[i] - arr[0]);
//             }
//         }
//     }
// }

// function bestSingleBuySell(arr) {
//     var profits = [];
//     if (arr.length < 2) {
//         return false;
//     } else {
//         for (var i = 0; i < arr.length-1; i++) {
//             for (var j = i+1; j < arr.length; j++) {
//                 profits.push(arr[j] - arr[i]);
//             }
//         }
//         return Math.max.apply(null, profits);
//     }
// }

function bestSingleBuySell(arr) {
    if (arr.length < 2) {
        return -1;
    }
    var maxDiff = -1;
    var min = arr[0];
    for (var i = 1; i < arr.length; i++) {
        if (arr[i] < min) {
            min = arr[i];
            continue;
        }
        if (arr[i] - min > maxDiff) {
            maxDiff = arr[i] - min;
        }
    }
    return maxDiff;
}

console.log(bestSingleBuySell([6,4,6,5,9,7,6,12,2,6,11,2,4]));
console.log(bestSingleBuySell([6,4,6,5,9,7,6,12,2,6,11,3,14]));
console.log(bestSingleBuySell([4,1,2,3]));