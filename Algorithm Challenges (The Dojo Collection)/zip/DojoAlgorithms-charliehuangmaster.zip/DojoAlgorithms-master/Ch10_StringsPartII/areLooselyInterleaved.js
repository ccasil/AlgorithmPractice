/* Given three strings, return boolean of if the third string is a peroper (no duplicates) interleaving of the first two. Given ("dne", "ail", "daniel"), return true. Given ("dne", "ail", "dalein"), return false. */

function areLooselyInterleaved(str1, str2, str3) {
    if (str3.length !== str1.length + str2.length || 
        str2.length > str1.length ||
        str1.length - str2.length > 1) {
        return false;
    }
    var index = 0;
    for (var i = 0; i < str1.length; i++) {
        if (str1[i] !== str3[index]) {
            return false;
        }
        index++;
        if (i < str2.length) {
            if (str2[i] !== str3[index]) { 
                return false;
            }
            index++;
        } else {
            break;
        }
    }
    return true;
}

console.log(areLooselyInterleaved("dne", "ail", "daniel"));
console.log(areLooselyInterleaved("dne", "ail", "dalein"));
console.log(areLooselyInterleaved("dne", "ail", "ddaanneeiill"));
console.log(areLooselyInterleaved("dne", "ai", "daniel"));
console.log(areLooselyInterleaved("dn", "aiel", "daniel"));
console.log(areLooselyInterleaved("dniel", "a", "daniel"));