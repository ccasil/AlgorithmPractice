/* Return all permutations of a given string */

function allPermutations(str) {
    var arr = [];
    getPermutations(str, arr);

    var dict = {};
    for (var i = 0; i < arr.length; i++) {
        if (!dict[arr[i]]) {
            dict[arr[i]] = arr[i];
        }
    }
    
    var output = [];
    for (var key in dict) {
        output.push(dict[key]);
    }
    return output;

    function getPermutations(str, arr) {
        if (str.length === 1) {
            arr.push(str[0]);
        } else {
            getPermutations(str.slice(1), arr);
            var oldLength = arr.length;
            for (var i = 0; i < oldLength; i++) {
                var temp = arr.pop();
                for (var j = 0; j <= temp.length; j++) {
                    var newPerm = temp.slice(0, j) + str[0] + temp.slice(j);
                    arr.unshift(newPerm);
                }
            }
        }
    }
}

console.log(allPermutations("team"));
console.log(allPermutations("teem"));