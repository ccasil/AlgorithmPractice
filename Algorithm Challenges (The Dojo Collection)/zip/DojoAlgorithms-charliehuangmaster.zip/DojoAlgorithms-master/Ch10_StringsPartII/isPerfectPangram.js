/* Return if a string contains all 26 letters in the English alphabet (upper or lower case) once and only once. */

function isPerfectPangram(str) {
    var dict = {'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 0, 'f': 0, 'g': 0, 'h': 0, 'i': 0, 'j': 0, 'k': 0, 'l': 0, 'm': 0, 'n': 0, 'o': 0, 'p': 0, 'q': 0, 'r': 0, 's': 0, 't': 0, 'u': 0, 'v': 0, 'w': 0, 'x': 0, 'y': 0, 'z': 0};
    
        for (var i = 0; i < str.length; i++) {
            var letter = str[i].toLowerCase();
            if (letter in dict) {
                dict[letter]++;
            }
        }

        for (var letter in dict) {
            if (dict[letter] !== 1) {
                return false;
            }
        }
        return true;
}

console.log(isPerfectPangram("Playing jazz vibe chords quickly excites my wife."));
console.log(isPerfectPangram("Mr. Jock, TV quiz PhD, bags few lynx."));