/* Create a function that converts a number into a string containing those  exact numerals. Given 1234, return the string "1234". */

function numToString(num) {
    if (num === 0) {
        return "0";
    } else if (num % 1 !== 0) {
        var output = "";
        output += num % 1;
        if (num < 0) {
            output = output.slice(2);
        } else {
            output = output.slice(1);
        }
        return numToString(Math.trunc(num)) + output;
    } else {
        if (num > 0) {
            return posNumToString(num);
        } else if (num < 0) {
            var output = posNumToString(Math.abs(num));
            return "-" + output;
        } else {
            return "0";
        }
    }

    function posNumToString(num) {
        var output = "";
        while (num > 0) {
            output = num % 10 + output;
            num = Math.floor(num/10);
        }
        return output;
    }
}

console.log(numToString(1234));
console.log(typeof numToString(1234));
console.log(numToString(1000));
console.log(typeof numToString(1000));
console.log(numToString(4001));
console.log(typeof numToString(4001));
console.log(numToString(001));
console.log(typeof numToString(001));
console.log(numToString(-385));
console.log(typeof numToString(-385));
console.log(numToString(-3.85));
console.log(typeof numToString(-3.85));
console.log(numToString(3.85));
console.log(typeof numToString(3.85));