/* Given two strings, the second string contains characters that must be removed from the first. Return a string fromed by removing any instances of those characters from the first string */

function badCharacters(str1, str2) {
    var dict = {};
    for (var i = 0; i < str2.length; i++) {
        if (!dict[str2[i]]) {
            dict[str2[i]] = true;
        }
    }

    var output = "";
    for (var i = 0; i < str1.length; i++) {
        if (!dict[str1[i]]) {
            output += str1[i];
        }
    }
    return output;
}

console.log(badCharacters("the quick brown fox jumped over the lazy dog", "aeiou"));