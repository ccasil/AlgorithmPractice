/* Given a string, return the index of the first character which, if removed, converts a string into a palindrome. If the string is already palindromic, return -1. Assume there will always be a solution for the string provided. */

function makePalindromeRemove(str) {
    if (isPalindrome(str)) {
        return -1;
    }

    for (var i =0; i < str.length; i++) {
        if (isPalindrome(str.slice(0, i) + str.slice(i+1))) {
            return i;
        }
    }

    return -1;

    function isPalindrome(str) {
        for (var i = 0; i < str.length/2; i++) {
            if (str[i] !== str[str.length-1-i]) {
                return false;
            }
        }
        return true;
    }
}

console.log(makePalindromeRemove("dude"));
console.log(makePalindromeRemove("racecar"));
console.log(makePalindromeRemove("racec2ar"));
console.log(makePalindromeRemove("abcde"));