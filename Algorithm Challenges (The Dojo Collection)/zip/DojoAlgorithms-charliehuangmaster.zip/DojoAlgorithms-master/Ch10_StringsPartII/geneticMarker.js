/* Given an array of strings and a string, return a boolean for if the string is found anywhere in the array. Strings in the array might contain the '?' wildcard character, signifying that ican represent any character needed in order to complete a match. */

function geneticMarker(arr, str) {
    for (var i = 0; i < arr.length; i++) {
        if (isSubStr(arr[i], str)) {
            return true;
        }
    }
    return false;
}

function isSubStr(str1, str2) {
    for (var i = 0; i < str1.length; i++) {
        var sub = str1.slice(i, i+str2.length);
        for (var j = 0; j < sub.length; j++) {
            if (sub[j] === "?") {
                sub = sub.slice(0, j) + str2[j] + sub.slice(j+1);
            }
        }
        if (sub === str2) {
            return true;
        }
    }
    return false;
}

console.log(geneticMarker(["??hello", "xhr??", "hex?e?"], "xreh"));
console.log(geneticMarker(["??hello", "xhr??", "hex?en"], "xreh"));