/* Check if two given strings are rotations of each other */

function isRotation(str1, str2) {
    if (str1.length !== str2.length) {
        return false;
    }
    var newStr = str1 + str1;
    for (var i = 0; i < newStr.length; i++) {
        var subStr = newStr.slice(i, i + str1.length);
        if (subStr === str2) {
            return true;
        }
    }
    return false;
}

console.log(isRotation("hello", "llohe"));
console.log(isRotation("hello", "lloho"));