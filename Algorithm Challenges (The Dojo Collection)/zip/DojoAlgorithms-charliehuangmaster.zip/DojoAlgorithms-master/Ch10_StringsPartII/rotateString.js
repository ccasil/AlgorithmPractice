/* Given a string and an integer, rotate the characters in the string to the right by the integer amount.

e.g. rotateString("Boris Godunov", 5) returns "dunovBoris Go" */

function rotateString(str, num) {
    for (var i = 0; i < num; i++) {
        str = str[str.length-1] + str;
        str = str.slice(0, str.length-1);
    }
    return str;
}

console.log(rotateString("Boris Godunov", 5));