/* Given a string of words, return an array of words. */

function stringToWords(str) {
    var wordsArr = [];
    var word = "";
    for (var i = 0; i < str.length; i++) {
        if (str[i] !== " ") {
            word += str[i];
        } else {
            wordsArr.push(word);
            word = "";
        }
    }
    wordsArr.push(word);
    return wordsArr;
}

console.log(stringToWords("Life is not a drill!"));