/* Given a string that may contain sequences of consecutive characters, create a function to shorten the string by including the character, then the number of times it appears.

e.g. For "aaaabbcddd", return "a4b2c1d3". If the encoded string is not shorter than the original string, return the original string. */

function encode(str) {
    var output = str[0];
    var counter = 1;
    for (var i =1; i < str.length; i++) {
        if (str[i] === str[i-1]) {
            counter++;
        } else {
            output += counter + str[i];
            counter = 1;
        }
    }
    output += counter;
    
    if (output.length >= str.length) {
        return str;
    } else {
        return output;
    }
}

console.log(encode("aaaabbcddd"));
console.log(encode("ab"));