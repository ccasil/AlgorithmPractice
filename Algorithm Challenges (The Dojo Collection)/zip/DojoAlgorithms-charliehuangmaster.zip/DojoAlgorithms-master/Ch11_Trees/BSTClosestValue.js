/* Return the value contained in a BST that is closest to the given value. This could be the exact value (if the BST contains it), or one that is greater or less than the given value. Note: there is no guarantee that the closest v alue is a direct parent, grandparent, child, grandchild, etc. */

BST.prototype.closestValue = function(val) {
    var arr = [];
    var returned = rSearch(val, this.root);
    if (returned === undefined) {
        return arr.pop();
    } else {
        return returned;
    }

    function rSearch(val, root) {
        if (root.left) {
            rSearch(val, root.left);
        }

        if (root.val === val) {
            return val;
        } else if (root.val > val) {
            if (arr.length === 0) {
                return root.val;
            } else {
                var dL = val - arr[0];
                var dR = root.val - val;
                if (dL < dR) {
                    return arr[0];
                } else {
                    return root.val;
                }
            }
        } else {
            arr.pop();
            arr.push(root.val);
        }

        if (root.right) {
            rSearch(val, root.right);
        }
    }
}