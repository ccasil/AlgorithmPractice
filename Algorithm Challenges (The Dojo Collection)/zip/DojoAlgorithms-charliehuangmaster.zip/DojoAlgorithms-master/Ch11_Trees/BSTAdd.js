/* Create a method on the BST object to add a new value to the tree. This entails creating a BTNode with this value and connecting it at the appropriate place in the tree. Unless specified otherwise, BSTs can contain duplicate values. */

function BST() {
    this.root = null;
}

function BTNode(value) {
    this.val = value;
    this.left = null;
    this.right = null;
}

BST.prototype.add = function(val) {
    var runner = this.root;
    while (runner) {
        if (val < runner.val) {
            if (runner.left) {
                runner = runner.left;
            } else {
                runner.left = new BTNode(val);
                break;
            }
        } else {
            if (runner.right) {
                runner = runner.right;
            } else {
                runner.right = new BTNode(val);
                break;
            }
        }
    }
}

BST.prototype.add = function(val) {
    addNode(val, this.root);
    function addNode(val, root) {
        if (val < root.val) {
            if (root.left) {
                addNode(val, root.left);
            } else {
                root.left = new BTNode(val);
                return;
            }
        } else {
            if (root.right) {
                addNode(val, root.right);
            } else {
                root.right = new BTNode(val);
                return;
            }
        }
    }
}