/* Given a value that may or may not be in the BST, return the value that is most immediately smaller. */

BST.prototype.valBefore = function(val) {
    var arr = []
    var returned = rSearch(val, this.root);
    if (returned == null) {
        return arr.pop();
    } else {
        return returned;
    }

    function rSearch(val, root) {
        if (root.left) {
            rSearch(val, root.left);
        }
        if (root.val >= val) {
            return arr.pop();
        } else {
            arr.push(root.val);
        }
        if (root.right) {
            rSearch(val, root.right);
        }
    }
}