/* Return the BST's minimum height - the shortest sequence of nodes from root to any leaf */

BST.prototype.height = function() {
    return getHeight(this.root);

    function getHeight(root) {
        if (!root) {
            return 0;
        } else {
            h1 = getHeight(root.left) + 1;
            h2 = getHeight(root.right) + 1;
            if (h1 < h2) {
                return h1;
            } else {
                return h2;
            }
        }
    }
}