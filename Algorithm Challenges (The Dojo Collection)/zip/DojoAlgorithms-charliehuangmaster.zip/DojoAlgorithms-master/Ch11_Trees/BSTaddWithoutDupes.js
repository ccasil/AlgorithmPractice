/* Add a given value to the BST only if it s not already found. Return true if added, false otherwise. */

BST.prototype.addWithoutDupes = function(val) {
    rAdd(val, this.root);

    function rAdd(val, root) {
        if (val === root.val) {
            return false;
        } else if (val < root.val) {
            if (root.left) {
                rAdd(val, root.left);
            } else {
                root.left = new BTNode(val);
                return true;
            }
        } else {
            if (root.right) {
                rAdd(val, root.right);
            } else {
                root.right = new BTNode(val);
                return true;
            }
        }
    }
}