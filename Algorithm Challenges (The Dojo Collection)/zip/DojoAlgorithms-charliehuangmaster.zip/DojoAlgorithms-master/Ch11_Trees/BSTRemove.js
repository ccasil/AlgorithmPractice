/* Remove a given value from the BST or return false if not found. */

BST.prototype.remove = function(val) {
    rRemove(val, this.root);

    function rRemove(val, root) {
        if (!root.left && !root.right) {
            return false;
        } else if (root.left.val !== val && root.right.val !== val) {
            if (val < root.val) {
                rRemove(val, root.left);
            } else {
                rRemove(val, root.right);
            }
        } else {
            if (root.left.val === val) {
                if (!root.left.left && !root.left.right) {
                    root.left = null;
                } else if (!root.left.right) {
                    root.left = root.left.left;
                } else {
                    var temp = root.left.right.min();
                    root.left.val = temp;
                    rRemove(temp, root.left.right);
                }
            } else {
                if (!root.right.left && !root.right.right) {
                    root.right = null;
                } else if (!root.right.left) {
                    root.right = root.right.right;
                } else {
                    var temp = root.right.right.min();
                    root.right.val = temp;
                    rRemove(temp, root.right.right);
                }
            }
        }
    }
}