/* Given a binary tree (not necessarily a BST) that contains values between 0 and 9, consider the digits encountered in order when traversing from root-to-leaf to be that path's root-leaf number. For example, the root-to-leaf path 4->2->3 represents the root-leaf number 423. Return an array of all root-leaf numbers found in the given binary tree. */

function rootLeafNumbers(tree) {
    var arr = [];
    rRLN(tree.root, "");
    return arr;

    function rRLN(root, rlnStr) {
        rlnStr += root.val;
        if (!root.left && !root.right) {
            arr.push(rlnStr.parseInt());
        }
        if (root.left) {
            rRLN(root.left, rlnStr);
        }
        if (root.right) {
            rRLN(root.right, rlnStr);
        }
    }
}