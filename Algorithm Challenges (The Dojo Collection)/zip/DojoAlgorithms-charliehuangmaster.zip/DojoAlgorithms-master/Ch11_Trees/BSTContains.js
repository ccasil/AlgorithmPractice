/* Create a method on BST that returns if the tree contains the given value. */

function BST() {
    this.root = null;
}

function BTNode(value) {
    this.val = value;
    this.left = null;
    this.right = null;
}

BST.prototype.contains = function(val) {
    return findVal(val, this.root);
    function findVal(val, root) {
        if (!root) {
            return false;
        } else if (root.val === val) {
            return true;
        } else {
            if (val < root.val) {
                return findVal(val, root.left);
            } else {
                return findVal(val, root.right);
            }
        }
    }
}