/* Return the number of nodes (values) contained in the tree */

BST.prototype.size = function() {
    var size = 0;
    findSize(this.root, size);
    return size;

    function findSize(root, size) {
        if (root) {
            size++;
            findSize(root.left, size);
            findSize(root.right, size);
        }
    }
}