/* Given a value that may or may not be in the BST, return the value in the BST immediately following the given one. Return null if the value comes after the last node in the BST. */

BST.prototype.valAfter = function(val) {
    var arr = [];
    var returned = rSearch(val, this.root);
    if (returned === undefined) {
        return null;
    } else {
        return returned;
    }

    function rSearch(val, root) {
        if (root.left) {
            rSearch(val, root.left);
        }
        if (root.val > val) {
            return root.val;
        }
        if (root.right) {
            rSearch(val, root.right);
        }
    }
}