/* Determine if a BST has valid structure. Specifically, ensure that all nodes and values are located in the appropriate left or right subtrees. */

BST.prototype.isValid = function() {
    return (rValid(this.root.left, this.root, this.root.val) && 
            rValid(this.root.right, this.root, this.root.val));

    function rValid(root, parent, rootVal) {
        if (!root.left && !root.right) {
            return true;
        } else {
            if (root.left.val >= root.val || root.right.val < root.val) {
                return false;
            }
            if (root.val < parent) {
                if (root.right.val >= parent || root.right.val >= rootVal) {
                    return false;
                }
            } else {
                if (root.left.val < parent || root.left.val < rootVal) {
                    return false;
                }
            }
            return (rValid(root.left, root, rootVal) && 
                    rValid(root.right, root, rootVal));
        }
    }
}