/* Given a binary tree, return an array containing the root value and the values of only the leftmost of children at each level. */

function leftSideBinaryTree(tree) {
    var arr = [];
    rLeft(tree.root);
    return arr;

    function rLeft(root) {
        if (root) {
            arr.push(root.val);
        }
        if (root.left) {
            rLeft(root.left);
        }
    }
}