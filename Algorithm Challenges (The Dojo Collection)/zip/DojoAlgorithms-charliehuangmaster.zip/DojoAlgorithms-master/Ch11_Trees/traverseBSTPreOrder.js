/* Create a function that prints the BST's values traversed pre-order. */

function bstPreOrder(bst) {
    var arr = [];
    printBST(bst.root);
    return arr;

    function printBST(root) {
        arr.push(root.val);
        if (root.left) {
            printBST(root.left);
        }
        if (root.right) {
            printBST(root.right);
        }
    }
}

// NON-RECURSIVE
function bstPreOrder(bst) {
    var arr = [];
    var stack = [];
    stack.push(bst.root);
    while (stack.length > 0) {
        var node = stack.pop();
        arr.push(node.val);
        if (node.right) {
            stack.push(node.right);
        }
        if (node.left) {
            stack.push(node.left);
        }
    }
    return arr;
}