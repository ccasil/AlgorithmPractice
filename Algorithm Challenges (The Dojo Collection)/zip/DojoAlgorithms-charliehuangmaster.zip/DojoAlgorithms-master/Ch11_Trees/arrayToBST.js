/* Given an array sorted in ascending order, return a BST object that is height-balanced */

function arrayToBST(arr) {
    var bst = new BST();
    var midIndex = Math.floor(arr.length/2);
    bst.root = new BTNode(arr[midIndex]);
    for (var i = 0; i < arr.length; i++) {
        if (i !== midIndex) {
            bst.add(new BTNode(arr[i]));
        }
    }
    return bst;
}