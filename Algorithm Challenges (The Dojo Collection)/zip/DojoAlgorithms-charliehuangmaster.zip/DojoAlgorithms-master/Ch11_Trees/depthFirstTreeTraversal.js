/* Given a starting node, print the nodes of the tree and their depth level using depth-first traversal.

Example:
         A
         |
  ---------------
  |      |      |
  B      C      D
 / \            |
X  Y            Z

Input: node A
Output: [['X', 2], ['Y', 2], ['B', 1], ['C', 1], ['Z', 2], ['D', 1], ['A', 0]]
*/

function Node(val) {
  this.val = val;
  this.children = [];
}

function depthFirst(rootNode) {
  var outputArr = [];
  traverse(rootNode, outputArr, 0);
  function traverse(node, arr, depth) {
    if (node.children.length !== 0) {
      for (var i = 0; i < node.children.length; i++) {
        traverse(node.children[i], arr, depth+1);
      }
    }
    arr.push([node.val, depth]);
  }
  return outputArr;
}

var a = new Node('A');
var b = new Node('B');
var c = new Node('C');
var d = new Node('D');
var x = new Node('X');
var y = new Node('Y');
var z = new Node('Z');
a.children = [b, c, d];
b.children = [x, y];
d.children = [z];

console.log(depthFirst(a));