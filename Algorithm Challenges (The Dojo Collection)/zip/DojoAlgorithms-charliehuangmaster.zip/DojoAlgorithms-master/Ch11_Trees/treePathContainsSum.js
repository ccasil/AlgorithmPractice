/* Given a binary tree (not necessarily a BST) and a sum, determine if the tree as a root-to-leaf path where the sum of node values in the path equals the given sum. If a particular node has (for example) a left child but no right child, it can be considered a leaf. */

function treePathContainsSum(tree, sum) {
    if (!tree.root) {
        return false;
    }
    return rSum(tree.root, sum, 0);

    function rSum(root, sum, currSum) {
        if (!root) {
            return false;
        }
        currSum += root.val;
        if (currSum > sum) {
            return false;
        } else if (currSum === sum) {
            if (!root.left || !root.right) {
                return true;
            }
        } else {
            if (!root.left && !root.right) {
                return false;
            } else {
                return (rSum(root.left, sum, currSum) || 
                        rSum(root.right, sum, currSum));
            }
        }
    }
}