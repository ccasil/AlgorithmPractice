/* Return if a BST is balanced. Consider a tree balanced when all nodes are ablanced--if heights of a node's left subtree and right subtree differ by at most one. */

BST.prototype.isBalanced = function() {
    return balanced(this.root);
    function balanced(root) {
        if (root) {
            if (root.height() - root.minHeight() > 1) {
                return false;
            }
            if (balanced(root.left) === false || 
                balanced(root.right) === false) {
                    return false;
            }
            return true;
        }
    }
}