/* Given a BST and two contained values, return the value of the closest common ancestor node. For each node, the chain up to root represents that node's ancestry. Return the value of the node in both ancestor chains that is closest to both. */

function closestCommonAncestor(bst, val1, val2) {
    if (!bst.root.contains(val1) && !bst.root.contains(val2)) {
        return null;
    }
    return getAncestor(bst.root, val1, val2);

    function getAncestor(root, val1, val2) {
        if (root.left.contains(val1) && root.left.contains(val2)) {
            return getAncestor(root.left, val1, val2);
        } else if (root.right.contains(val1) && root.right.contains(val2)) {
            return getAncestor(root.right, val1, val2);
        } else {
            return root;
        }
    }
}