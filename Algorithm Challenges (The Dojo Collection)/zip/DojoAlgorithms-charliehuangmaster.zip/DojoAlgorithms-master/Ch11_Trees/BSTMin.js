/* Return the smallest value found in the BST */

function BST() {
    this.root = null;
}

function BTNode(value) {
    this.val = value;
    this.left = null;
    this.right = null;
}

BST.prototype.min = function() {
    return findMin(this.root);
    function findMin(root) {
        if (!root.left) {
            return root.val;
        } else {
            return findMin(root.left);
        }
    }
}