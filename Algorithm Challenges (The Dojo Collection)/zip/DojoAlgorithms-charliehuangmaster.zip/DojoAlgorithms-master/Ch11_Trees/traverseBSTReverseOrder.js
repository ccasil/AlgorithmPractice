/* Given a BST, return an array of the BST's values traversed in reverse order */

function bstReverseOrder(bst) {
    var arr = [];
    printBST(bst.root);
    return arr;

    function printBST(root) {
        if (root.right) {
            printBST(root.right);
        }
        arr.push(root.val);
        if (root.left) {
            printBST(root.left);
        }
    }
}