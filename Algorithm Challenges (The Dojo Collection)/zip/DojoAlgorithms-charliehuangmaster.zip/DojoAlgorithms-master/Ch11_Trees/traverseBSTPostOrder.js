/* Create a function that prints the BST's values traversed post-order. */

function bstPostOrder(bst) {
    var arr = [];
    printBST(bst.root);
    return arr;

    function printBST(root) {
        if (root.left) {
            printBST(root.left);
        }
        if (root.right) {
            printBST(root.right);
        }
        arr.push(root.val);
    }
}