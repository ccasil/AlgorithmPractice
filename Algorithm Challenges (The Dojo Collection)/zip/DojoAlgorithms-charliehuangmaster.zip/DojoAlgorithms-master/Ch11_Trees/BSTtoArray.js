/* Create a function that prints the BST's values traversed in order. */

function bstToArray(bst) {
    var arr = [];
    printBST(bst.root);
    return arr;

    function printBST(root) {
        if (root.left) {
            printBST(root.left);
        }
        arr.push(root.val);
        if (root.right) {
            printBST(root.right);
        }
    }
}