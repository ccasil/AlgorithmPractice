/* Create an insert method to insert a string to the Trie set. Assume the input strings will be letters only, all lowercase. Return false if the word has already been stored (after all, it's a Trie set, not multiset), or true if insertion was successful. */

function TrieNode(val) {
    this.val = val;
    this.isWord = false;
    this.children = {};
}

function Trie() {
    this.root = new TrieNode(null);
}

Trie.prototype.insert = function(val) {
    var runner = this.root;
    for (let i = 0; i < val.length; i++) {
        var sub = val.slice(0, i+1);
        if (!runner.children[sub]) {
            runner.children[sub] = new TrieNode(sub);
        }
        if (sub.length === val.length) {
            runner.children[sub].isWord = true;
        }
        runner = runner.children[sub];
    }
}