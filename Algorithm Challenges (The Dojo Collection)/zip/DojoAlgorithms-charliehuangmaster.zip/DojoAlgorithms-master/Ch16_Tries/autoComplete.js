/* Assuming a trie is populated with a wide array of valid words, return an array of words beginning with a given string. */

function TrieNode(val) {
    this.val = val;
    this.isWord = false;
    this.children = {};
}

function Trie() {
    this.root = new TrieNode(null);
}

Trie.prototype.autoComplete = function(search) {
    var runner = this.root;
    for (let i = 0; i < search.length; i++) {
        let sub = search.slice(0, i+1);
        if (runner.children[sub]) {
            runner = runner.children[sub];
        } else {
            break;
        }
    }
    if (runner.val !== search) {
        return [];
    }
    var words = [];
    runner.findWords(words);
    return words;
}

TrieNode.prototype.findWords = function(arr) {
    if (!Object.keys(this.children).length) {
        return;
    } else {
        for (var key in this.children) {
            if (this.children[key].isWord) {
                arr.push(this.children[key].val);
            }
            this.children[key].findWords(arr);
        }
    }
}