function twelveBarBlues(){
    for (var i = 1; i <= 12; i++){
        console.log(i);
        console.log("chick");
        console.log("boom");
        console.log("chick");
    }
}

twelveBarBlues()
