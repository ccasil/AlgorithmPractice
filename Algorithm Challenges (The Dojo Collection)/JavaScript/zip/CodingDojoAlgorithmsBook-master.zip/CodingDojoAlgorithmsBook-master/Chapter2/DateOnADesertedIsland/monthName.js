function monthName(monthNum){
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    return months[monthNum-1];
}

monthName(5)
