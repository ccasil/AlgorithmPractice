// dayNum is a number up to 140,000
// Note: years 2100, 2200 and 2300 are NOT leap years,
// although 2400 is!
function fullDate3(dayNum){

}

fullDate3(139947) // "Tuesday, February 29, 2400"
