How many values are accepted by the == and === operators?
2

Do inputs to the == and === operators need to be of the same data type?
No for ==
Yes for === <- incorrect

Answer: They do not need to be of the same type for either operator.
However, if not the same type, === returns false.
The == operator insternally converts values to the same type before comparing.


What is the data type returned by the == and === operators?
Boolean
