function printAndReturn(num1, num2){
    console.log(num1);
    return num2;
}

printAndReturn(5,1)
