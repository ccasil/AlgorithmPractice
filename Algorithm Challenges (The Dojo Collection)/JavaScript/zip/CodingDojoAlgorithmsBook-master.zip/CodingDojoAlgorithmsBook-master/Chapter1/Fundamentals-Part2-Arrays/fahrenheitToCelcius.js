function fahrenheitToCelcius(fDegrees){
    return ((fDegrees - 32) * 5)/ 9;
}

fahrenheitToCelcius(32)
