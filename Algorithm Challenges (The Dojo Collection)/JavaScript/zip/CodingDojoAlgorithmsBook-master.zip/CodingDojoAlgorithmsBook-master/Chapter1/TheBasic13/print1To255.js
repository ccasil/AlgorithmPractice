function print1To255(){
    for (var i = 1; i <= 255; i++){
        console.log(i);
    }
}

print1To255()
