function returnOddsArray1To255(){
    var arr = [];
    for (var i = 1; i <= 255; i+=2){
        arr.push(i);
    }
    return arr;
}

returnOddsArray1To255()
