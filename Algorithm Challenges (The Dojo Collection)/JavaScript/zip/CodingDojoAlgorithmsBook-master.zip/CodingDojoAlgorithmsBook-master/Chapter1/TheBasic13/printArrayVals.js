function printArrayVals(arr){
    for (var i = 0; i< arr.length; i++){
        console.log(arr[i]);
    }
}

printArrayVals([,6,5,4,3,2,1])
