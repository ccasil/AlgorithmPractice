function printOdds1To255(){
    for (var i = 1; i <= 255; i+=2){
        console.log(i);
    }
}

printOdds1To255()
