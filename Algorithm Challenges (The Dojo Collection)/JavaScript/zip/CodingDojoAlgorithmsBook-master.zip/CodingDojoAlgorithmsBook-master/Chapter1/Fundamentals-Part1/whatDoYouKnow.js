function whatDoYouKnow(incoming){
    console.log(incoming);
}

whatDoYouKnow("testvalue")
