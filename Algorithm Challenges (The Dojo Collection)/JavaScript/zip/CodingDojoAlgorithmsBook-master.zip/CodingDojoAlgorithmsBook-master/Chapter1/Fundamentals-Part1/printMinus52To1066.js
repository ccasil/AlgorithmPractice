function printMinus52To1066(){
    for (var i = -52; i <= 1066; i++){
        console.log(i);
    }
}

printMinus52To1066()
