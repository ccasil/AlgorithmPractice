function printingIntegersWithWhile(){
    var i = 2000;
    while (i <= 5280){
        console.log(i);
        i++;
    }
}

printingIntegersWithWhile()
