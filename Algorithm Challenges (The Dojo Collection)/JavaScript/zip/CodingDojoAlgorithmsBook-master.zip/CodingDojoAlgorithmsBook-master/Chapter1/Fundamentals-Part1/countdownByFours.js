function countdownByFours(){
    var num = 2016;
    while (num > 0){
        console.log(num);
        num -=4;
    }
}

countdownByFours()
