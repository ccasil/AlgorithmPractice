function beCheerful(){
    for (var i = 1; i <= 98; i++){
        console.log("good morning!");
    }
}

beCheerful()
