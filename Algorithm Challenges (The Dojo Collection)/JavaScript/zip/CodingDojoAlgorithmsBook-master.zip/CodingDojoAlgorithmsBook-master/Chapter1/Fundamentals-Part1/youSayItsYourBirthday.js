function youSayItsYourBirthday(num1,num2){
    if ((num1==2 && num2==14)|| (num1==14 && num2==2)){
        console.log("How did you know?");
    }
    else{
        console.log("Just another day...");
    }
}

youSayItsYourBirthday(15,2)
