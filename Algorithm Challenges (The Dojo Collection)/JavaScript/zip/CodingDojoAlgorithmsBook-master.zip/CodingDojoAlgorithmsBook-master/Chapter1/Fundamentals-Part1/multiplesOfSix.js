function multiplesOfSix(){
    var i = 6;
    while (i <= 60000){
        console.log(i);
        i += 6;
    }
}

multiplesOfSix()
