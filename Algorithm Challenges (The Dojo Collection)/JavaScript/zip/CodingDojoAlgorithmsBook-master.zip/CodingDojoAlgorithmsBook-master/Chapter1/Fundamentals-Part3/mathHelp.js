function mathHelp(M,B){
    return "X-intercept is " + (0-B)/M;
}

mathHelp(2,5)
